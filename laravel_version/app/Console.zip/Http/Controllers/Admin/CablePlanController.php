<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\CablePlan;
use App\Models\CableId;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Response;

class CablePlanController extends Controller
{
    /**
     * Display a listing of cable plans
     */
    public function index()
    {
        $cablePlans = CablePlan::with('provider')
            ->orderBy('created_at', 'desc')
            ->get();
            
        $providers = CableId::active()->get();
        
        return view('admin.cable-plans.index', compact('cablePlans', 'providers'));
    }

    /**
     * Store a newly created cable plan
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'provider' => 'required|exists:cable_ids,cId',
            'planname' => 'required|string|max:255',
            'planid' => 'required|string|max:255',
            'duration' => 'required|integer|min:1',
            'price' => 'required|numeric|min:0',
            'userprice' => 'required|numeric|min:0',
            'agentprice' => 'required|numeric|min:0',
            'vendorprice' => 'required|numeric|min:0',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        // Check for duplicate plan ID within same provider
        $existingPlan = CablePlan::where('cableprovider', $request->provider)
            ->where('planid', $request->planid)
            ->first();

        if ($existingPlan) {
            return response()->json([
                'success' => false,
                'message' => 'A plan with this ID already exists for this provider'
            ], 422);
        }

        // Validate pricing tiers
        if ($request->userprice < $request->price) {
            return response()->json([
                'success' => false,
                'message' => 'User price cannot be less than buying price'
            ], 422);
        }

        $plan = CablePlan::create([
            'name' => $request->planname,
            'price' => $request->price,
            'userprice' => $request->userprice,
            'agentprice' => $request->agentprice,
            'vendorprice' => $request->vendorprice,
            'planid' => $request->planid,
            'cableprovider' => $request->provider,
            'day' => $request->duration,
            'status' => 'active'
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Cable plan added successfully',
            'plan' => $plan
        ]);
    }

    /**
     * Display the specified cable plan
     */
    public function show($id)
    {
        $plan = CablePlan::with('provider')->findOrFail($id);
        
        return response()->json([
            'success' => true,
            'plan' => $plan
        ]);
    }

    /**
     * Update the specified cable plan
     */
    public function update(Request $request, $id)
    {
        $plan = CablePlan::findOrFail($id);

        $validator = Validator::make($request->all(), [
            'provider' => 'required|exists:cable_ids,cId',
            'planname' => 'required|string|max:255',
            'planid' => 'required|string|max:255',
            'duration' => 'required|integer|min:1',
            'price' => 'required|numeric|min:0',
            'userprice' => 'required|numeric|min:0',
            'agentprice' => 'required|numeric|min:0',
            'vendorprice' => 'required|numeric|min:0',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        // Check for duplicate plan ID within same provider (excluding current plan)
        $existingPlan = CablePlan::where('cableprovider', $request->provider)
            ->where('planid', $request->planid)
            ->where('cpId', '!=', $id)
            ->first();

        if ($existingPlan) {
            return response()->json([
                'success' => false,
                'message' => 'A plan with this ID already exists for this provider'
            ], 422);
        }

        // Validate pricing tiers
        if ($request->userprice < $request->price) {
            return response()->json([
                'success' => false,
                'message' => 'User price cannot be less than buying price'
            ], 422);
        }

        $plan->update([
            'name' => $request->planname,
            'price' => $request->price,
            'userprice' => $request->userprice,
            'agentprice' => $request->agentprice,
            'vendorprice' => $request->vendorprice,
            'planid' => $request->planid,
            'cableprovider' => $request->provider,
            'day' => $request->duration
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Cable plan updated successfully',
            'plan' => $plan
        ]);
    }

    /**
     * Remove the specified cable plan
     */
    public function destroy($id)
    {
        $plan = CablePlan::findOrFail($id);
        $plan->delete();

        return response()->json([
            'success' => true,
            'message' => 'Cable plan deleted successfully'
        ]);
    }

    /**
     * Toggle plan status
     */
    public function toggleStatus($id)
    {
        $plan = CablePlan::findOrFail($id);
        $plan->status = $plan->status === 'active' ? 'inactive' : 'active';
        $plan->save();

        return response()->json([
            'success' => true,
            'message' => 'Plan status updated successfully',
            'status' => $plan->status
        ]);
    }

    /**
     * Bulk delete plans
     */
    public function bulkDelete(Request $request)
    {
        $planIds = $request->input('plan_ids');
        
        if (!is_array($planIds) || empty($planIds)) {
            return response()->json([
                'success' => false,
                'message' => 'No plans selected'
            ], 422);
        }

        $deletedCount = CablePlan::whereIn('cpId', $planIds)->delete();

        return response()->json([
            'success' => true,
            'message' => "{$deletedCount} plans deleted successfully"
        ]);
    }

    /**
     * Bulk update prices
     */
    public function bulkUpdatePrices(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'plan_ids' => 'required|string',
            'price_type' => 'required|in:price,userprice,agentprice,vendorprice',
            'adjustment_type' => 'required|in:percentage,fixed',
            'adjustment_value' => 'required|numeric'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        $planIds = json_decode($request->plan_ids, true);
        $priceType = $request->price_type;
        $adjustmentType = $request->adjustment_type;
        $adjustmentValue = $request->adjustment_value;

        $plans = CablePlan::whereIn('cpId', $planIds)->get();
        $updatedCount = 0;

        foreach ($plans as $plan) {
            $currentPrice = $plan->{$priceType};
            
            if ($adjustmentType === 'percentage') {
                $newPrice = $currentPrice * (1 + ($adjustmentValue / 100));
            } else {
                $newPrice = $currentPrice + $adjustmentValue;
            }

            // Ensure price doesn't go below 0
            $newPrice = max(0, $newPrice);

            $plan->{$priceType} = round($newPrice, 2);
            $plan->save();
            $updatedCount++;
        }

        return response()->json([
            'success' => true,
            'message' => "{$updatedCount} plans updated successfully"
        ]);
    }

    /**
     * Export plans to CSV
     */
    public function export(Request $request)
    {
        $format = $request->get('format', 'csv');
        
        $plans = CablePlan::with('provider')->get();

        if ($format === 'csv') {
            $filename = 'cable_plans_' . date('Y-m-d_H-i-s') . '.csv';
            
            $headers = [
                'Content-Type' => 'text/csv',
                'Content-Disposition' => "attachment; filename=\"{$filename}\"",
            ];

            $callback = function() use ($plans) {
                $file = fopen('php://output', 'w');
                
                // CSV header
                fputcsv($file, [
                    'ID', 'Name', 'Provider', 'Plan ID', 'Duration (Days)',
                    'Buying Price', 'User Price', 'Agent Price', 'Vendor Price',
                    'Status', 'Created At'
                ]);

                // CSV data
                foreach ($plans as $plan) {
                    fputcsv($file, [
                        $plan->cpId,
                        $plan->name,
                        $plan->provider ? $plan->provider->provider : 'N/A',
                        $plan->planid,
                        $plan->day,
                        $plan->price,
                        $plan->userprice,
                        $plan->agentprice,
                        $plan->vendorprice,
                        $plan->status,
                        $plan->created_at ? $plan->created_at->format('Y-m-d H:i:s') : 'N/A'
                    ]);
                }

                fclose($file);
            };

            return Response::stream($callback, 200, $headers);
        }

        return response()->json(['error' => 'Unsupported format'], 400);
    }

    /**
     * Get cable plan statistics
     */
    public function getStatistics()
    {
        $stats = CablePlan::getStatistics();
        
        return response()->json([
            'success' => true,
            'statistics' => $stats
        ]);
    }

    /**
     * Get plans by provider
     */
    public function getPlansByProvider(Request $request)
    {
        $providerId = $request->get('provider_id');
        
        if (!$providerId) {
            return response()->json([
                'success' => false,
                'message' => 'Provider ID is required'
            ], 422);
        }

        $plans = CablePlan::where('cableprovider', $providerId)
            ->where('status', 'active')
            ->get();

        return response()->json([
            'success' => true,
            'plans' => $plans
        ]);
    }
}
