<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DataPlan extends Model
{
    use HasFactory;

    protected $table = 'data_plans';
    protected $primaryKey = 'dId';
    public $timestamps = false;

    protected $fillable = [
        'dNetwork',
        'dPlan',
        'dGroup',
        'dUserPrice',
        'dAgentPrice',
        'dVendorPrice',
        'dAmount',
        'dValidity',
        'dPlanId'
    ];

    protected $casts = [
        'dUserPrice' => 'float',
        'dAgentPrice' => 'float',
        'dVendorPrice' => 'float',
    ];

    /**
     * Get network details
     */
    public function network()
    {
        return $this->belongsTo(NetworkId::class, 'dNetwork', 'nId');
    }

    /**
     * Get price based on user type
     */
    public function getPriceForUserType($userType)
    {
        switch ($userType) {
            case 1: // Regular User
                return $this->dUserPrice;
            case 2: // Agent
                return $this->dAgentPrice;
            case 3: // Vendor
                return $this->dVendorPrice;
            default:
                return $this->dUserPrice;
        }
    }

    /**
     * Get data plans by network and group
     */
    public static function getByNetworkAndGroup($networkId, $group = 'SME')
    {
        return static::where('dNetwork', $networkId)
                    ->where('dGroup', $group)
                    ->orderBy('dUserPrice', 'asc')
                    ->get();
    }

    /**
     * Get plan by network and plan ID
     */
    public static function getByNetworkAndPlanId($networkId, $planId)
    {
        return static::where('dNetwork', $networkId)
                    ->where('dPlanId', $planId)
                    ->first();
    }

    /**
     * Format plan display name
     */
    public function getDisplayNameAttribute()
    {
        return $this->dPlan . ' (' . $this->dValidity . ')';
    }

    /**
     * Get formatted amount
     */
    public function getFormattedAmountAttribute()
    {
        return number_format($this->dAmount, 0) . 'MB';
    }

    /**
     * Calculate final amount after discount
     */
    public function calculateFinalAmount($userType)
    {
        return $this->getPriceForUserType($userType);
    }

    /**
     * Calculate profit from transaction
     */
    public function calculateProfit($finalAmount)
    {
        // Profit is the difference between user price and what we actually pay
        $cost = $this->dUserPrice * 0.95; // Assuming 5% cost reduction
        return max(0, $finalAmount - $cost);
    }

    /**
     * Get plan description for transactions
     */
    public function getsPlanAttribute()
    {
        return $this->dPlan;
    }

    /**
     * Get plan ID for API calls
     */
    public function getPlanIdAttribute()
    {
        return $this->dPlanId;
    }
}
