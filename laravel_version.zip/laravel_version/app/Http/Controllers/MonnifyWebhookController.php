<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\MonnifyService;
use Illuminate\Support\Facades\Log;

class MonnifyWebhookController extends Controller
{
    protected $monnifyService;

    public function __construct(MonnifyService $monnifyService)
    {
        $this->monnifyService = $monnifyService;
    }

    /**
     * Handle Monnify webhook notifications
     */
    public function handleWebhook(Request $request)
    {
        try {
            $payload = $request->getContent();
            $signature = $request->header('Monnify-Signature');

            Log::info('Monnify webhook received', [
                'headers' => $request->headers->all(),
                'payload' => $payload
            ]);

            if (!$signature) {
                Log::warning('Monnify webhook missing signature');
                return response()->json(['error' => 'Missing signature'], 400);
            }

            // Verify webhook signature
            if (!$this->monnifyService->verifyWebhookSignature($payload, $signature)) {
                Log::warning('Monnify webhook invalid signature');
                return response()->json(['error' => 'Invalid signature'], 401);
            }

            // Process the webhook
            $result = $this->monnifyService->processWebhook($payload);

            if ($result['success']) {
                Log::info('Monnify webhook processed successfully', $result);
                return response()->json(['status' => 'success'], 200);
            }

            Log::warning('Monnify webhook processing failed', $result);
            return response()->json(['error' => $result['message']], 400);

        } catch (\Exception $e) {
            Log::error('Monnify webhook error: ' . $e->getMessage(), [
                'trace' => $e->getTraceAsString()
            ]);

            return response()->json(['error' => 'Internal server error'], 500);
        }
    }
}
