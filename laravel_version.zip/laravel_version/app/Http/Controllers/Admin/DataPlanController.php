<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\DataPlan;
use App\Models\NetworkId;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class DataPlanController extends Controller
{
    /**
     * Display a listing of data plans
     */
    public function index()
    {
        $dataPlans = DataPlan::with(['network'])->orderBy('pId', 'desc')->get();
        $networks = NetworkId::all();
        
        return view('admin.data-plans.index', compact('dataPlans', 'networks'));
    }

    /**
     * Show the form for creating a new data plan
     */
    public function create()
    {
        $networks = NetworkId::all();
        return view('admin.data-plans.create', compact('networks'));
    }

    /**
     * Store a newly created data plan
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'network' => 'required|exists:network_ids,nId',
            'dataname' => 'required|string|max:255',
            'datatype' => 'required|in:Gifting,SME,Corporate',
            'planid' => 'required|string|unique:dataplans,planid',
            'duration' => 'required|integer|min:1',
            'price' => 'required|numeric|min:0',
            'userprice' => 'required|numeric|min:0',
            'agentprice' => 'required|numeric|min:0',
            'vendorprice' => 'required|numeric|min:0',
        ]);

        if ($validator->fails()) {
            if ($request->ajax()) {
                return response()->json(['errors' => $validator->errors()], 422);
            }
            return redirect()->back()->withErrors($validator)->withInput();
        }

        $network = NetworkId::find($request->network);
        
        $dataPlan = DataPlan::create([
            'dNetwork' => $request->network,
            'name' => $request->dataname,
            'type' => $request->datatype,
            'planid' => $request->planid,
            'day' => $request->duration,
            'price' => $request->price,
            'userprice' => $request->userprice,
            'agentprice' => $request->agentprice,
            'vendorprice' => $request->vendorprice,
            'datanetwork' => strtolower($network->network),
        ]);

        if ($request->ajax()) {
            return response()->json([
                'success' => true,
                'message' => 'Data plan created successfully',
                'plan' => $dataPlan->load('network')
            ]);
        }

        return redirect()->route('admin.data-plans.index')
            ->with('success', 'Data plan created successfully');
    }

    /**
     * Display the specified data plan
     */
    public function show(DataPlan $dataPlan)
    {
        $dataPlan->load('network');
        return view('admin.data-plans.show', compact('dataPlan'));
    }

    /**
     * Show the form for editing the specified data plan
     */
    public function edit(DataPlan $dataPlan)
    {
        $networks = NetworkId::all();
        $dataPlan->load('network');
        return view('admin.data-plans.edit', compact('dataPlan', 'networks'));
    }

    /**
     * Update the specified data plan
     */
    public function update(Request $request, DataPlan $dataPlan)
    {
        $validator = Validator::make($request->all(), [
            'network' => 'required|exists:network_ids,nId',
            'dataname' => 'required|string|max:255',
            'datatype' => 'required|in:Gifting,SME,Corporate',
            'planid' => 'required|string|unique:dataplans,planid,' . $dataPlan->pId . ',pId',
            'duration' => 'required|integer|min:1',
            'price' => 'required|numeric|min:0',
            'userprice' => 'required|numeric|min:0',
            'agentprice' => 'required|numeric|min:0',
            'vendorprice' => 'required|numeric|min:0',
        ]);

        if ($validator->fails()) {
            if ($request->ajax()) {
                return response()->json(['errors' => $validator->errors()], 422);
            }
            return redirect()->back()->withErrors($validator)->withInput();
        }

        $network = NetworkId::find($request->network);
        
        $dataPlan->update([
            'dNetwork' => $request->network,
            'name' => $request->dataname,
            'type' => $request->datatype,
            'planid' => $request->planid,
            'day' => $request->duration,
            'price' => $request->price,
            'userprice' => $request->userprice,
            'agentprice' => $request->agentprice,
            'vendorprice' => $request->vendorprice,
            'datanetwork' => strtolower($network->network),
        ]);

        if ($request->ajax()) {
            return response()->json([
                'success' => true,
                'message' => 'Data plan updated successfully',
                'plan' => $dataPlan->load('network')
            ]);
        }

        return redirect()->route('admin.data-plans.index')
            ->with('success', 'Data plan updated successfully');
    }

    /**
     * Remove the specified data plan
     */
    public function destroy(DataPlan $dataPlan)
    {
        $dataPlan->delete();

        if (request()->ajax()) {
            return response()->json([
                'success' => true,
                'message' => 'Data plan deleted successfully'
            ]);
        }

        return redirect()->route('admin.data-plans.index')
            ->with('success', 'Data plan deleted successfully');
    }

    /**
     * Bulk delete data plans
     */
    public function bulkDelete(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'plan_ids' => 'required|array',
            'plan_ids.*' => 'exists:dataplans,pId'
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        DataPlan::whereIn('pId', $request->plan_ids)->delete();

        return response()->json([
            'success' => true,
            'message' => count($request->plan_ids) . ' data plans deleted successfully'
        ]);
    }

    /**
     * Toggle plan status
     */
    public function toggleStatus(DataPlan $dataPlan)
    {
        $dataPlan->update([
            'status' => $dataPlan->status === 'active' ? 'inactive' : 'active'
        ]);

        return response()->json([
            'success' => true,
            'status' => $dataPlan->status,
            'message' => 'Plan status updated successfully'
        ]);
    }

    /**
     * Bulk update prices
     */
    public function bulkUpdatePrices(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'plan_ids' => 'required|array',
            'plan_ids.*' => 'exists:dataplans,pId',
            'price_type' => 'required|in:price,userprice,agentprice,vendorprice',
            'adjustment_type' => 'required|in:percentage,fixed',
            'adjustment_value' => 'required|numeric',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $plans = DataPlan::whereIn('pId', $request->plan_ids)->get();
        $priceField = $request->price_type;
        $adjustmentType = $request->adjustment_type;
        $adjustmentValue = $request->adjustment_value;

        foreach ($plans as $plan) {
            $currentPrice = $plan->$priceField;
            
            if ($adjustmentType === 'percentage') {
                $newPrice = $currentPrice + ($currentPrice * ($adjustmentValue / 100));
            } else {
                $newPrice = $currentPrice + $adjustmentValue;
            }
            
            $plan->update([$priceField => max(0, $newPrice)]);
        }

        return response()->json([
            'success' => true,
            'message' => 'Prices updated successfully for ' . count($request->plan_ids) . ' plans'
        ]);
    }

    /**
     * Get plans by network
     */
    public function getByNetwork(Request $request)
    {
        $networkId = $request->get('network_id');
        $dataType = $request->get('data_type');
        
        $query = DataPlan::where('dNetwork', $networkId);
        
        if ($dataType) {
            $query->where('type', $dataType);
        }
        
        $plans = $query->orderBy('userprice')->get();
        
        return response()->json($plans);
    }

    /**
     * Export data plans
     */
    public function export(Request $request)
    {
        $format = $request->get('format', 'csv');
        $plans = DataPlan::with('network')->get();
        
        if ($format === 'csv') {
            $filename = 'data_plans_' . date('Y-m-d_H-i-s') . '.csv';
            $headers = [
                'Content-Type' => 'text/csv',
                'Content-Disposition' => 'attachment; filename="' . $filename . '"',
            ];
            
            return response()->stream(function() use ($plans) {
                $file = fopen('php://output', 'w');
                
                // CSV Headers
                fputcsv($file, [
                    'ID', 'Network', 'Name', 'Type', 'Plan ID', 'Days', 
                    'Price', 'User Price', 'Agent Price', 'Vendor Price', 'Status'
                ]);
                
                foreach ($plans as $plan) {
                    fputcsv($file, [
                        $plan->pId,
                        $plan->network->network ?? 'N/A',
                        $plan->name,
                        $plan->type,
                        $plan->planid,
                        $plan->day,
                        $plan->price,
                        $plan->userprice,
                        $plan->agentprice,
                        $plan->vendorprice,
                        $plan->status ?? 'active'
                    ]);
                }
                
                fclose($file);
            }, 200, $headers);
        }
        
        return response()->json(['error' => 'Unsupported format'], 400);
    }

    /**
     * Get plan statistics
     */
    public function getStatistics()
    {
        $stats = [
            'total_plans' => DataPlan::count(),
            'active_plans' => DataPlan::where('status', 'active')->count(),
            'by_network' => DataPlan::select('datanetwork')
                ->selectRaw('count(*) as count')
                ->groupBy('datanetwork')
                ->get(),
            'by_type' => DataPlan::select('type')
                ->selectRaw('count(*) as count')
                ->groupBy('type')
                ->get(),
            'avg_prices' => [
                'user' => DataPlan::avg('userprice'),
                'agent' => DataPlan::avg('agentprice'),
                'vendor' => DataPlan::avg('vendorprice'),
            ]
        ];
        
        return response()->json($stats);
    }
}
