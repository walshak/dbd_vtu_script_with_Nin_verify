<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\AirtimeService;
use App\Services\FailoverService;
use App\Services\LoggingService;
use App\Models\NetworkId;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class AirtimeController extends Controller
{
    protected $airtimeService;
    protected $failoverService;
    protected $loggingService;

    public function __construct(
        AirtimeService $airtimeService,
        FailoverService $failoverService,
        LoggingService $loggingService
    ) {
        $this->airtimeService = $airtimeService;
        $this->failoverService = $failoverService;
        $this->loggingService = $loggingService;
    }

    /**
     * Show airtime purchase page
     */
    public function index()
    {
        $networks = NetworkId::getSupportedNetworks();
        return view('airtime.index', compact('networks'));
    }

    /**
     * Get airtime pricing for a network
     */
    public function getPricing(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'network' => 'required|string'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Invalid network selected'
            ], 400);
        }

        $pricing = $this->airtimeService->getAirtimePricing(
            Auth::id(),
            $request->network
        );

        return response()->json([
            'status' => 'success',
            'data' => $pricing
        ]);
    }

    /**
     * Purchase airtime
     */
    public function purchase(Request $request)
    {
        $startTime = microtime(true);

        // Log the incoming request
        $this->loggingService->logApiRequest(
            $request->path(),
            $request->method(),
            $request->except(['password', 'token']),
            [],
            0,
            0,
            'internal'
        );

        $validator = Validator::make($request->all(), [
            'network' => 'required|string',
            'phone' => 'required|string|regex:/^[0-9]{11}$/',
            'amount' => 'required|numeric|min:50|max:10000',
            'type' => 'required|string|in:VTU,Share and Sell'
        ]);

        if ($validator->fails()) {
            $responseTime = round((microtime(true) - $startTime) * 1000, 2);

            // Log validation failure
            $this->loggingService->logTransaction(
                'airtime_purchase',
                'validation_failed',
                $request->all(),
                Auth::id(),
                [
                    'validation_errors' => $validator->errors(),
                    'response_time_ms' => $responseTime
                ]
            );

            return response()->json([
                'status' => 'error',
                'message' => $validator->errors()->first()
            ], 400);
        }

        // Use FailoverService for automatic provider failover
        $requestData = [
            'phone' => $request->phone,
            'amount' => $request->amount,
            'network' => $request->network,
            'type' => $request->type,
            'user_id' => Auth::id()
        ];

        try {
            $result = $this->failoverService->executeWithFailover('airtime', $requestData);
            $responseTime = round((microtime(true) - $startTime) * 1000, 2);

            // Log transaction result
            $this->loggingService->logTransaction(
                'airtime_purchase',
                $result['status'] === 'success' ? 'success' : 'error',
                $requestData,
                Auth::id(),
                [
                    'provider_used' => $result['metadata']['provider_used'] ?? 'unknown',
                    'response_time_ms' => $responseTime,
                    'failover_used' => $result['metadata']['failover_used'] ?? false,
                    'attempted_providers' => $result['metadata']['attempted_providers'] ?? []
                ]
            );

            // Log performance metrics
            $this->loggingService->logPerformance(
                'airtime_purchase_complete',
                $responseTime,
                [
                    'amount' => $request->amount,
                    'network' => $request->network,
                    'provider_response_time' => $result['metadata']['response_time'] ?? 0
                ],
                [
                    'user_id' => Auth::id(),
                    'success' => $result['status'] === 'success'
                ]
            );

            if ($result['status'] === 'success') {
                return response()->json($result);
            } else {
                return response()->json($result, $result['code'] ?? 400);
            }

        } catch (\Exception $e) {
            $responseTime = round((microtime(true) - $startTime) * 1000, 2);

            // Log the exception
            $this->loggingService->logError($e, [
                'operation' => 'airtime_purchase',
                'request_data' => $requestData,
                'user_id' => Auth::id(),
                'response_time_ms' => $responseTime
            ]);

            return response()->json([
                'status' => 'error',
                'message' => 'Transaction failed due to system error'
            ], 500);
        }
    }

    /**
     * Get transaction history for airtime
     */
    public function history()
    {
        $transactions = $this->airtimeService->getAirtimeHistory(Auth::id());

        return view('user.airtime-history', compact('transactions'));
    }

    /**
     * API endpoint for mobile app
     */
    public function apiPurchase(Request $request)
    {
        $startTime = microtime(true);

        // Log API request for mobile
        $this->loggingService->logApiRequest(
            $request->path(),
            $request->method(),
            $request->except(['password', 'token']),
            [],
            0,
            0,
            'mobile_api'
        );

        $validator = Validator::make($request->all(), [
            'network' => 'required|string',
            'phone' => 'required|string|regex:/^[0-9]{11}$/',
            'amount' => 'required|numeric|min:50|max:10000',
            'type' => 'required|string|in:VTU,Share and Sell'
        ]);

        if ($validator->fails()) {
            $responseTime = round((microtime(true) - $startTime) * 1000, 2);

            // Log validation failure for API
            $this->loggingService->logTransaction(
                'airtime_api_purchase',
                'validation_failed',
                $request->all(),
                Auth::id(),
                [
                    'validation_errors' => $validator->errors(),
                    'response_time_ms' => $responseTime,
                    'api_client' => 'mobile'
                ]
            );

            return response()->json([
                'status' => 'error',
                'message' => $validator->errors()->first()
            ], 400);
        }

        // Use FailoverService for automatic provider failover
        $requestData = [
            'phone' => $request->phone,
            'amount' => $request->amount,
            'network' => $request->network,
            'type' => $request->type,
            'user_id' => Auth::id()
        ];

        try {
            $result = $this->failoverService->executeWithFailover('airtime', $requestData);
            $responseTime = round((microtime(true) - $startTime) * 1000, 2);

            // Log API transaction result
            $this->loggingService->logTransaction(
                'airtime_api_purchase',
                $result['status'] === 'success' ? 'success' : 'error',
                $requestData,
                Auth::id(),
                [
                    'provider_used' => $result['metadata']['provider_used'] ?? 'unknown',
                    'response_time_ms' => $responseTime,
                    'failover_used' => $result['metadata']['failover_used'] ?? false,
                    'api_client' => 'mobile'
                ]
            );

            return response()->json($result);

        } catch (\Exception $e) {
            $responseTime = round((microtime(true) - $startTime) * 1000, 2);

            // Log API exception
            $this->loggingService->logError($e, [
                'operation' => 'airtime_api_purchase',
                'request_data' => $requestData,
                'user_id' => Auth::id(),
                'response_time_ms' => $responseTime,
                'api_client' => 'mobile'
            ]);

            return response()->json([
                'status' => 'error',
                'message' => 'Transaction failed due to system error'
            ], 500);
        }
    }
}
