<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\UserLogin;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Carbon\Carbon;

class AuthController extends Controller
{
    /**
     * Show login form
     */
    public function showLoginForm()
    {
        if (Auth::check()) {
            return redirect()->intended('/dashboard');
        }
        
        return view('auth.login');
    }

    /**
     * Handle login request
     */
    public function login(Request $request)
    {
        $request->validate([
            'phone' => 'required|string',
            'password' => 'required|string'
        ]);

        try {
            // Find user by phone number  
            $user = User::where('sPhone', $request->phone)->first();
            
            if (!$user) {
                if ($request->wantsJson()) {
                    return response()->json([
                        'status' => 'error',
                        'message' => 'Phone number not found. Please check your phone number.'
                    ], 401);
                }
                return back()->withErrors([
                    'phone' => 'Phone number not found. Please check your phone number.'
                ])->withInput($request->except('password'));
            }

            // Check if account is blocked
            if ($user->isBlocked()) {
                if ($request->wantsJson()) {
                    return response()->json([
                        'status' => 'error',
                        'message' => 'Your account has been blocked. Please contact support.'
                    ], 401);
                }
                return back()->withErrors([
                    'phone' => 'Your account has been blocked. Please contact support.'
                ])->withInput($request->except('password'));
            }

            // For existing system compatibility - check plain text password first
            $passwordMatch = ($user->sPass === $request->password) || Hash::check($request->password, $user->sPass);
            
            if (!$passwordMatch) {
                // Log failed login attempt
                Log::warning('Failed login attempt', [
                    'phone' => $request->phone, 
                    'user_id' => $user->sId,
                    'ip' => $request->ip()
                ]);
                
                if ($request->wantsJson()) {
                    return response()->json([
                        'status' => 'error',
                        'message' => 'Invalid password. Please check your password.'
                    ], 401);
                }
                return back()->withErrors([
                    'password' => 'Invalid password. Please check your password.'
                ])->withInput($request->except('password'));
            }

            // Update last activity
            $user->update(['sLastActivity' => now()]);

            // Login successful
            Auth::login($user, $request->boolean('remember'));
            $request->session()->regenerate();
            
            Log::info('User logged in successfully', [
                'user_id' => $user->sId, 
                'phone' => $user->sPhone,
                'ip' => $request->ip()
            ]);
            
            if ($request->wantsJson()) {
                return response()->json([
                    'status' => 'success',
                    'message' => 'Login successful! Welcome back.',
                    'user' => [
                        'id' => $user->sId,
                        'name' => $user->sFname . ' ' . $user->sLname,
                        'sFname' => $user->sFname,
                        'phone' => $user->sPhone,
                        'email' => $user->sEmail,
                        'wallet' => $user->sWallet,
                        'account_type' => $user->account_type_name
                    ]
                ]);
            }
            
            return redirect()->intended('/dashboard');
            
        } catch (\Exception $e) {
            Log::error('Login error', [
                'error' => $e->getMessage(),
                'phone' => $request->phone,
                'ip' => $request->ip()
            ]);
            
            if ($request->wantsJson()) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'An error occurred during login. Please try again.'
                ], 500);
            }
            
            return back()->withErrors([
                'phone' => 'An error occurred during login. Please try again.'
            ])->withInput($request->except('password'));
        }
    }
            
            // Log successful login
            $this->logLoginAttempt($user->sId, $request->ip(), true);
            
            // Update last login
            $user->sLastLogin = now();
            $user->save();

            return redirect()->intended('/dashboard')->with('success', 'Welcome back, ' . $user->sFname . '!');

        } catch (\Exception $e) {
            Log::error('Login error: ' . $e->getMessage());
            return back()->withErrors([
                'login' => 'An error occurred during login. Please try again.'
            ])->withInput($request->except('password'));
        }
    }

    /**
     * Show registration form
     */
    public function showRegistrationForm()
    {
        if (Auth::check()) {
            return redirect('/dashboard');
        }
        
        return view('auth.register');
    }

    /**
     * Handle registration request
     */
    public function register(Request $request)
    {
        $request->validate([
            'fname' => 'required|string|max:255',
            'lname' => 'required|string|max:255',
            'email' => 'required|email|unique:subscribers,sEmail',
            'phone' => 'required|string|unique:subscribers,sPhone|regex:/^[0-9]{11}$/',
            'password' => 'required|string|min:8|max:15',
            'cpassword' => 'required|string|same:password',
            'state' => 'required|string|max:100',
            'transpin' => 'required|string|size:4|regex:/^[0-9]{4}$/',
            'account' => 'required|integer|in:1,2,3',
            'referal' => 'nullable|string'
        ]);

        try {
            // Check if referral user exists
            $referralUser = null;
            if ($request->referal) {
                $referralUser = User::where('sPhone', 'like', '%' . $request->referal)->first();
            }

            // Create user - store password as plain text for existing system compatibility
            $user = User::create([
                'sFname' => $request->fname,
                'sLname' => $request->lname,
                'sEmail' => $request->email,
                'sPhone' => $request->phone,
                'sPass' => $request->password, // Plain text for compatibility
                'sState' => $request->state,
                'sPin' => $request->transpin,
                'sType' => $request->account,
                'sRegStatus' => User::REG_STATUS_ACTIVE,
                'sWallet' => 0.00,
                'sRefWallet' => 0.00,
                'sPinStatus' => 'active',
                'sReferal' => $referralUser ? $referralUser->sPhone : null,
                'sApiKey' => User::generateApiKey($request->phone),
                'sRegDate' => now(),
                'sLastActivity' => now()
            ]);

            // Log the user in
            Auth::login($user);
            $request->session()->regenerate();
            
            Log::info('User registered successfully', [
                'user_id' => $user->sId, 
                'phone' => $user->sPhone,
                'email' => $user->sEmail,
                'ip' => $request->ip()
            ]);
            
            if ($request->wantsJson()) {
                return response()->json([
                    'status' => 'success',
                    'message' => 'Registration successful! Welcome to VASTLEAD .',
                    'user' => [
                        'id' => $user->sId,
                        'name' => $user->sFname . ' ' . $user->sLname,
                        'phone' => $user->sPhone,
                        'email' => $user->sEmail,
                        'wallet' => $user->sWallet,
                        'account_type' => $user->account_type_name
                    ]
                ]);
            }
            
            return redirect('/dashboard')->with('success', 'Registration successful! Welcome to VASTLEAD .');

        } catch (\Exception $e) {
            Log::error('Registration error', [
                'error' => $e->getMessage(),
                'phone' => $request->phone,
                'email' => $request->email,
                'ip' => $request->ip()
            ]);
            
            if ($request->wantsJson()) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'An error occurred during registration. Please try again.'
                ], 500);
            }
            
            return back()->withErrors([
                'email' => 'An error occurred during registration. Please try again.'
            ])->withInput($request->except(['password', 'cpassword', 'transpin']));
        }
    }
                'sEmailVerified' => false,
                'sVerificationToken' => Str::random(60),
                'created_at' => now(),
                'updated_at' => now()
            ]);

            // Send verification email
            $this->sendVerificationEmail($user);

            // Auto-login user
            Auth::login($user);

            return redirect('/dashboard')->with('success', 'Registration successful! Please check your email to verify your account.');

        } catch (\Exception $e) {
            Log::error('Registration error: ' . $e->getMessage());
            return back()->withErrors([
                'email' => 'An error occurred during registration. Please try again.'
            ])->withInput($request->except('password', 'password_confirmation'));
        }
    }

    /**
     * Handle logout request
     */
    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        
        return redirect('/')->with('success', 'You have been logged out successfully.');
    }

    /**
     * Show password reset request form
     */
    public function showPasswordResetForm()
    {
        return view('auth.forgot-password');
    }

    /**
     * Handle password reset request
     */
    public function sendPasswordResetLink(Request $request)
    {
        $request->validate([
            'email' => 'required|email|exists:subscribers,sEmail'
        ]);

        try {
            $user = User::where('sEmail', $request->email)->first();
            
            // Generate reset token
            $token = Str::random(60);
            
            // Store reset token (you might want to create a password_resets table)
            $user->sPasswordResetToken = $token;
            $user->sPasswordResetExpires = now()->addHours(1);
            $user->save();

            // Send reset email
            $this->sendPasswordResetEmail($user, $token);

            return back()->with('success', 'Password reset link sent to your email address.');

        } catch (\Exception $e) {
            Log::error('Password reset error: ' . $e->getMessage());
            return back()->withErrors([
                'email' => 'An error occurred. Please try again.'
            ]);
        }
    }

    /**
     * Show password reset form
     */
    public function showPasswordResetFormWithToken($token)
    {
        $user = User::where('sPasswordResetToken', $token)
                   ->where('sPasswordResetExpires', '>', now())
                   ->first();

        if (!$user) {
            return redirect()->route('password.request')
                           ->withErrors(['token' => 'Invalid or expired reset token.']);
        }

        return view('auth.reset-password', compact('token'));
    }

    /**
     * Handle password reset
     */
    public function resetPassword(Request $request)
    {
        $request->validate([
            'token' => 'required|string',
            'password' => 'required|string|min:6|confirmed'
        ]);

        try {
            $user = User::where('sPasswordResetToken', $request->token)
                       ->where('sPasswordResetExpires', '>', now())
                       ->first();

            if (!$user) {
                return back()->withErrors(['token' => 'Invalid or expired reset token.']);
            }

            // Update password
            $user->sPass = Hash::make($request->password);
            $user->sPasswordResetToken = null;
            $user->sPasswordResetExpires = null;
            $user->save();

            return redirect()->route('login')->with('success', 'Password reset successfully. You can now login with your new password.');

        } catch (\Exception $e) {
            Log::error('Password reset error: ' . $e->getMessage());
            return back()->withErrors(['password' => 'An error occurred. Please try again.']);
        }
    }

    /**
     * Verify email address
     */
    public function verifyEmail($token)
    {
        try {
            $user = User::where('sVerificationToken', $token)->first();

            if (!$user) {
                return redirect()->route('login')
                               ->withErrors(['verification' => 'Invalid verification token.']);
            }

            if ($user->sEmailVerified) {
                return redirect()->route('dashboard')
                               ->with('info', 'Email already verified.');
            }

            $user->sEmailVerified = true;
            $user->sVerificationToken = null;
            $user->save();

            return redirect()->route('dashboard')
                           ->with('success', 'Email verified successfully!');

        } catch (\Exception $e) {
            Log::error('Email verification error: ' . $e->getMessage());
            return redirect()->route('login')
                           ->withErrors(['verification' => 'An error occurred during verification.']);
        }
    }

    /**
     * Resend verification email
     */
    public function resendVerificationEmail(Request $request)
    {
        $user = Auth::user();

        if ($user->sEmailVerified) {
            return back()->with('info', 'Email already verified.');
        }

        try {
            // Generate new token if needed
            if (!$user->sVerificationToken) {
                $user->sVerificationToken = Str::random(60);
                $user->save();
            }

            $this->sendVerificationEmail($user);

            return back()->with('success', 'Verification email sent successfully.');

        } catch (\Exception $e) {
            Log::error('Resend verification error: ' . $e->getMessage());
            return back()->withErrors(['verification' => 'An error occurred. Please try again.']);
        }
    }

    /**
     * Log login attempt
     */
    private function logLoginAttempt($userId, $ipAddress, $successful)
    {
        try {
            UserLogin::create([
                'uUser' => $userId,
                'uIp' => $ipAddress,
                'uDate' => now(),
                'uSuccessful' => $successful,
                'uUserAgent' => request()->header('User-Agent')
            ]);
        } catch (\Exception $e) {
            Log::error('Failed to log login attempt: ' . $e->getMessage());
        }
    }

    /**
     * Check for too many failed attempts
     */
    private function tooManyFailedAttempts($userId)
    {
        $failedAttempts = UserLogin::where('uUser', $userId)
                                  ->where('uSuccessful', false)
                                  ->where('uDate', '>', now()->subMinutes(15))
                                  ->count();

        return $failedAttempts >= 5;
    }

    /**
     * Send verification email
     */
    private function sendVerificationEmail($user)
    {
        // Here you would send the actual email
        // For now, we'll just log it
        Log::info('Verification email would be sent to: ' . $user->sEmail, [
            'token' => $user->sVerificationToken,
            'user_id' => $user->sId
        ]);
    }

    /**
     * Send password reset email
     */
    private function sendPasswordResetEmail($user, $token)
    {
        // Here you would send the actual email
        // For now, we'll just log it
        Log::info('Password reset email would be sent to: ' . $user->sEmail, [
            'token' => $token,
            'user_id' => $user->sId
        ]);
    }
}