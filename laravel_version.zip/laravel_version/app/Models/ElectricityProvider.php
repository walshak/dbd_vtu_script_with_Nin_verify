<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ElectricityProvider extends Model
{
    use HasFactory;

    protected $table = 'electricity';
    protected $primaryKey = 'eId';
    public $timestamps = false;

    protected $fillable = [
        'ePlan',
        'eId',
        'ePrice',
        'eBuyingPrice',
        'eStatus'
    ];

    protected $casts = [
        'ePrice' => 'decimal:2',
        'eBuyingPrice' => 'decimal:2',
        'eStatus' => 'integer'
    ];

    /**
     * Status constants
     */
    const STATUS_ACTIVE = 1;
    const STATUS_INACTIVE = 0;

    /**
     * Scope for active providers
     */
    public function scopeActive($query)
    {
        return $query->where('eStatus', self::STATUS_ACTIVE);
    }

    /**
     * Get all active electricity providers
     */
    public static function getActiveProviders()
    {
        return static::active()->orderBy('ePlan')->get();
    }

    /**
     * Get provider by plan name
     */
    public static function getByPlan($planName)
    {
        return static::where('ePlan', $planName)->first();
    }

    /**
     * Get provider by external ID
     */
    public static function getByExternalId($externalId)
    {
        return static::where('eProviderId', $externalId)->first();
    }

    /**
     * Calculate user price based on account type
     */
    public function getUserPrice($accountType = 'user')
    {
        // Base electricity price with charges
        $basePrice = $this->ePrice;

        // Apply discounts based on account type
        switch (strtolower($accountType)) {
            case 'agent':
                return $basePrice * 0.99; // 1% discount
            case 'vendor':
                return $basePrice * 0.98; // 2% discount
            default:
                return $basePrice; // No discount for regular users
        }
    }

    /**
     * Calculate profit for transaction
     */
    public function calculateProfit($amount, $accountType = 'user')
    {
        $userPrice = $this->getUserPrice($accountType);
        $buyingPrice = $this->eBuyingPrice;

        // Calculate profit per unit and multiply by amount
        $profitPerUnit = $userPrice - $buyingPrice;
        return ($profitPerUnit / 100) * $amount; // Assuming amount is in currency units
    }

    /**
     * Check if provider is active
     */
    public function isActive()
    {
        return $this->eStatus == self::STATUS_ACTIVE;
    }

    /**
     * Toggle provider status
     */
    public function toggleStatus()
    {
        $this->eStatus = $this->eStatus == self::STATUS_ACTIVE ? self::STATUS_INACTIVE : self::STATUS_ACTIVE;
        return $this->save();
    }

    /**
     * Get status display name
     */
    public function getStatusDisplayAttribute()
    {
        return $this->eStatus == self::STATUS_ACTIVE ? 'Active' : 'Inactive';
    }

    /**
     * Get status badge class
     */
    public function getStatusBadgeClassAttribute()
    {
        return $this->eStatus == self::STATUS_ACTIVE ? 'badge-success' : 'badge-secondary';
    }

    /**
     * Get formatted plan name
     */
    public function getFormattedPlanAttribute()
    {
        return strtoupper($this->ePlan);
    }

    /**
     * Get provider logo
     */
    public function getLogoPathAttribute()
    {
        $logos = [
            'aedc' => '/assets/images/aedc-logo.png',
            'ekedc' => '/assets/images/ekedc-logo.png',
            'ikedc' => '/assets/images/ikedc-logo.png',
            'kedco' => '/assets/images/kedco-logo.png',
            'phed' => '/assets/images/phed-logo.png',
            'phcn' => '/assets/images/phcn-logo.png'
        ];

        $providerKey = strtolower(str_replace(' ', '', $this->ePlan));
        return $logos[$providerKey] ?? '/assets/images/electricity-default.png';
    }

    /**
     * Validate meter number format
     */
    public static function validateMeterNumber($meterNumber, $providerPlan = null)
    {
        // Remove spaces and special characters
        $meterNumber = preg_replace('/[^0-9]/', '', $meterNumber);

        // Basic validation - meter numbers are usually 11 digits
        if (strlen($meterNumber) < 10 || strlen($meterNumber) > 12) {
            return false;
        }

        // Additional provider-specific validations can be added here
        return true;
    }

    /**
     * Get service charges
     */
    public function getServiceCharges()
    {
        // Get charges from site settings
        $siteSettings = SiteSettings::getSiteSettings();
        return $siteSettings->electricitycharges ?? 50; // Default charge
    }
}
