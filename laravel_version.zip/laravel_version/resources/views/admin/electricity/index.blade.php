@extends('layouts.admin')

@section('title', 'Electricity Bill Management')

@section('content')
<div class="container-fluid">
    <!-- Header -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h1 class="h3 mb-0 text-gray-800">
                        <i class="fas fa-bolt text-warning"></i> Electricity Bill Management
                    </h1>
                    <p class="text-muted">Manage electricity providers, pricing, and service settings</p>
                </div>
                <div>
                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addProviderModal">
                        <i class="fas fa-plus"></i> Add Provider
                    </button>
                    <button type="button" class="btn btn-success ms-2" id="syncProvidersBtn">
                        <i class="fas fa-sync"></i> Sync Providers
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Statistics Cards -->
    <div class="row mb-4">
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                Active Providers
                            </div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800" id="activeProvidersCount">
                                {{ $statistics['active_providers'] }}
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-plug fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                Today's Transactions
                            </div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                {{ $statistics['today_transactions'] }}
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-chart-line fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                Today's Revenue
                            </div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                ₦{{ number_format($statistics['today_revenue'], 2) }}
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-naira-sign fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                Total Profit
                            </div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                ₦{{ number_format($statistics['total_profit'], 2) }}
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-coins fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Content Tabs -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <ul class="nav nav-tabs" id="electricityTabs" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="providers-tab" data-bs-toggle="tab" data-bs-target="#providers" type="button" role="tab">
                        <i class="fas fa-building"></i> Providers
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="transactions-tab" data-bs-toggle="tab" data-bs-target="#transactions" type="button" role="tab">
                        <i class="fas fa-list"></i> Transactions
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="settings-tab" data-bs-toggle="tab" data-bs-target="#settings" type="button" role="tab">
                        <i class="fas fa-cog"></i> Settings
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="api-config-tab" data-bs-toggle="tab" data-bs-target="#api-config" type="button" role="tab">
                        <i class="fas fa-plug"></i> API Config
                    </button>
                </li>
            </ul>
        </div>

        <div class="card-body">
            <div class="tab-content" id="electricityTabsContent">
                <!-- Providers Tab -->
                <div class="tab-pane fade show active" id="providers" role="tabpanel">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="providersTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Provider</th>
                                    <th>Status</th>
                                    <th>Buying Price</th>
                                    <th>Selling Price</th>
                                    <th>Profit Margin</th>
                                    <th>Last Updated</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($providers as $provider)
                                <tr>
                                    <td>{{ $provider->eId }}</td>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <img src="{{ $provider->logo_path }}" alt="{{ $provider->ePlan }}"
                                                 class="rounded-circle me-2" width="30" height="30">
                                            <strong>{{ strtoupper($provider->ePlan) }}</strong>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="badge {{ $provider->status_badge_class }}">
                                            {{ $provider->status_display }}
                                        </span>
                                    </td>
                                    <td>₦{{ number_format($provider->eBuyingPrice, 2) }}/kWh</td>
                                    <td>₦{{ number_format($provider->ePrice, 2) }}/kWh</td>
                                    <td>
                                        @php
                                            $margin = $provider->ePrice - $provider->eBuyingPrice;
                                            $percentage = $provider->eBuyingPrice > 0 ? ($margin / $provider->eBuyingPrice) * 100 : 0;
                                        @endphp
                                        <span class="text-{{ $percentage > 5 ? 'success' : ($percentage > 2 ? 'warning' : 'danger') }}">
                                            ₦{{ number_format($margin, 2) }} ({{ number_format($percentage, 1) }}%)
                                        </span>
                                    </td>
                                    <td>{{ $provider->updated_at ? $provider->updated_at->format('M d, Y H:i') : 'N/A' }}</td>
                                    <td>
                                        <div class="btn-group" role="group">
                                            <button type="button" class="btn btn-sm btn-outline-primary edit-provider"
                                                    data-id="{{ $provider->eId }}"
                                                    data-bs-toggle="tooltip" title="Edit Provider">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <button type="button" class="btn btn-sm btn-outline-{{ $provider->eStatus ? 'warning' : 'success' }} toggle-provider"
                                                    data-id="{{ $provider->eId }}"
                                                    data-bs-toggle="tooltip" title="{{ $provider->eStatus ? 'Disable' : 'Enable' }} Provider">
                                                <i class="fas fa-{{ $provider->eStatus ? 'pause' : 'play' }}"></i>
                                            </button>
                                            <button type="button" class="btn btn-sm btn-outline-danger delete-provider"
                                                    data-id="{{ $provider->eId }}"
                                                    data-name="{{ $provider->ePlan }}"
                                                    data-bs-toggle="tooltip" title="Delete Provider">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Transactions Tab -->
                <div class="tab-pane fade" id="transactions" role="tabpanel">
                    <div class="row mb-3">
                        <div class="col-md-3">
                            <select class="form-select" id="transactionStatus">
                                <option value="">All Status</option>
                                <option value="1">Successful</option>
                                <option value="0">Failed</option>
                                <option value="2">Pending</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <select class="form-select" id="transactionProvider">
                                <option value="">All Providers</option>
                                @foreach($providers as $provider)
                                <option value="{{ $provider->ePlan }}">{{ strtoupper($provider->ePlan) }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-md-3">
                            <input type="date" class="form-control" id="transactionDate" placeholder="Select Date">
                        </div>
                        <div class="col-md-3">
                            <button type="button" class="btn btn-primary w-100" id="filterTransactions">
                                <i class="fas fa-filter"></i> Filter
                            </button>
                        </div>
                    </div>

                    <div class="table-responsive">
                        <table class="table table-bordered" id="transactionsTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Reference</th>
                                    <th>User</th>
                                    <th>Provider</th>
                                    <th>Meter Number</th>
                                    <th>Amount</th>
                                    <th>Profit</th>
                                    <th>Status</th>
                                    <th>Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- Populated via AJAX -->
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Settings Tab -->
                <div class="tab-pane fade" id="settings" role="tabpanel">
                    <form id="electricitySettingsForm">
                        @csrf
                        <div class="row">
                            <div class="col-md-6">
                                <div class="card">
                                    <div class="card-header">
                                        <h5 class="mb-0">Service Configuration</h5>
                                    </div>
                                    <div class="card-body">
                                        <div class="mb-3">
                                            <label for="electricityCharges" class="form-label">Service Charges (₦)</label>
                                            <input type="number" class="form-control" id="electricityCharges"
                                                   name="electricity_charges" step="0.01"
                                                   value="{{ $settings['electricity_charges'] ?? 50 }}">
                                            <div class="form-text">Additional charges added to each transaction</div>
                                        </div>

                                        <div class="mb-3">
                                            <label for="minimumAmount" class="form-label">Minimum Amount (₦)</label>
                                            <input type="number" class="form-control" id="minimumAmount"
                                                   name="minimum_amount" value="{{ $settings['minimum_amount'] ?? 1000 }}">
                                        </div>

                                        <div class="mb-3">
                                            <label for="maximumAmount" class="form-label">Maximum Amount (₦)</label>
                                            <input type="number" class="form-control" id="maximumAmount"
                                                   name="maximum_amount" value="{{ $settings['maximum_amount'] ?? 50000 }}">
                                        </div>

                                        <div class="mb-3">
                                            <div class="form-check form-switch">
                                                <input class="form-check-input" type="checkbox" id="serviceEnabled"
                                                       name="service_enabled" {{ ($settings['service_enabled'] ?? true) ? 'checked' : '' }}>
                                                <label class="form-check-label" for="serviceEnabled">
                                                    Enable Electricity Service
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="card">
                                    <div class="card-header">
                                        <h5 class="mb-0">Discount Settings</h5>
                                    </div>
                                    <div class="card-body">
                                        <div class="mb-3">
                                            <label for="agentDiscount" class="form-label">Agent Discount (%)</label>
                                            <input type="number" class="form-control" id="agentDiscount"
                                                   name="agent_discount" step="0.01"
                                                   value="{{ $settings['agent_discount'] ?? 1 }}">
                                        </div>

                                        <div class="mb-3">
                                            <label for="vendorDiscount" class="form-label">Vendor Discount (%)</label>
                                            <input type="number" class="form-control" id="vendorDiscount"
                                                   name="vendor_discount" step="0.01"
                                                   value="{{ $settings['vendor_discount'] ?? 2 }}">
                                        </div>

                                        <div class="mb-3">
                                            <label for="maintenanceMode" class="form-label">Maintenance Message</label>
                                            <textarea class="form-control" id="maintenanceMessage"
                                                      name="maintenance_message" rows="3">{{ $settings['maintenance_message'] ?? 'Electricity service is temporarily unavailable. Please try again later.' }}</textarea>
                                        </div>

                                        <div class="mb-3">
                                            <div class="form-check form-switch">
                                                <input class="form-check-input" type="checkbox" id="maintenanceMode"
                                                       name="maintenance_mode" {{ ($settings['maintenance_mode'] ?? false) ? 'checked' : '' }}>
                                                <label class="form-check-label" for="maintenanceMode">
                                                    Maintenance Mode
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row mt-3">
                            <div class="col-12">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save"></i> Save Settings
                                </button>
                                <button type="button" class="btn btn-secondary ms-2" id="resetSettings">
                                    <i class="fas fa-undo"></i> Reset to Default
                                </button>
                            </div>
                        </div>
                    </form>
                </div>

                <!-- API Configuration Tab -->
                <div class="tab-pane fade" id="api-config" role="tabpanel">
                    <form id="apiConfigForm">
                        @csrf
                        <div class="row">
                            <div class="col-md-6">
                                <div class="card">
                                    <div class="card-header">
                                        <h5 class="mb-0">Primary API Configuration</h5>
                                    </div>
                                    <div class="card-body">
                                        <div class="mb-3">
                                            <label for="apiUrl" class="form-label">API URL</label>
                                            <input type="url" class="form-control" id="apiUrl"
                                                   name="electricity_api_url"
                                                   value="{{ $apiConfig['electricity_api_url'] ?? '' }}">
                                        </div>

                                        <div class="mb-3">
                                            <label for="apiKey" class="form-label">API Key</label>
                                            <div class="input-group">
                                                <input type="password" class="form-control" id="apiKey"
                                                       name="electricity_api_key"
                                                       value="{{ $apiConfig['electricity_api_key'] ?? '' }}">
                                                <button class="btn btn-outline-secondary" type="button" id="toggleApiKey">
                                                    <i class="fas fa-eye"></i>
                                                </button>
                                            </div>
                                        </div>

                                        <div class="mb-3">
                                            <label for="validationUrl" class="form-label">Validation URL</label>
                                            <input type="url" class="form-control" id="validationUrl"
                                                   name="electricity_validation_url"
                                                   value="{{ $apiConfig['electricity_validation_url'] ?? '' }}">
                                        </div>

                                        <div class="mb-3">
                                            <label for="authType" class="form-label">Authentication Type</label>
                                            <select class="form-select" id="authType" name="electricity_auth_type">
                                                <option value="basic" {{ ($apiConfig['electricity_auth_type'] ?? 'basic') == 'basic' ? 'selected' : '' }}>Basic Auth</option>
                                                <option value="token" {{ ($apiConfig['electricity_auth_type'] ?? 'basic') == 'token' ? 'selected' : '' }}>Bearer Token</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="card">
                                    <div class="card-header">
                                        <h5 class="mb-0">API Testing & Status</h5>
                                    </div>
                                    <div class="card-body">
                                        <div class="mb-3">
                                            <label for="testMeterNumber" class="form-label">Test Meter Number</label>
                                            <input type="text" class="form-control" id="testMeterNumber"
                                                   placeholder="Enter meter number for testing">
                                        </div>

                                        <div class="mb-3">
                                            <label for="testProvider" class="form-label">Test Provider</label>
                                            <select class="form-select" id="testProvider">
                                                <option value="">Select Provider</option>
                                                @foreach($providers as $provider)
                                                <option value="{{ $provider->ePlan }}">{{ strtoupper($provider->ePlan) }}</option>
                                                @endforeach
                                            </select>
                                        </div>

                                        <div class="d-grid gap-2">
                                            <button type="button" class="btn btn-info" id="testValidation">
                                                <i class="fas fa-check-circle"></i> Test Validation API
                                            </button>
                                            <button type="button" class="btn btn-warning" id="testPurchase">
                                                <i class="fas fa-shopping-cart"></i> Test Purchase API
                                            </button>
                                        </div>

                                        <div class="mt-3" id="apiTestResults" style="display: none;">
                                            <div class="alert alert-info">
                                                <strong>Test Results:</strong>
                                                <pre id="testResultsContent"></pre>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row mt-3">
                            <div class="col-12">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save"></i> Save API Configuration
                                </button>
                                <button type="button" class="btn btn-secondary ms-2" id="testConnection">
                                    <i class="fas fa-link"></i> Test Connection
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Add Provider Modal -->
<div class="modal fade" id="addProviderModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add Electricity Provider</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form id="addProviderForm">
                @csrf
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="providerPlan" class="form-label">Provider Name</label>
                        <input type="text" class="form-control" id="providerPlan" name="ePlan" required>
                        <div class="form-text">e.g., AEDC, EKEDC, IKEDC, KEDCO</div>
                    </div>

                    <div class="mb-3">
                        <label for="providerId" class="form-label">Provider Code</label>
                        <input type="text" class="form-control" id="providerId" name="eProviderId">
                        <div class="form-text">API provider identifier</div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="buyingPrice" class="form-label">Buying Price (₦/kWh)</label>
                                <input type="number" class="form-control" id="buyingPrice" name="eBuyingPrice" step="0.01" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="sellingPrice" class="form-label">Selling Price (₦/kWh)</label>
                                <input type="number" class="form-control" id="sellingPrice" name="ePrice" step="0.01" required>
                            </div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="providerStatus" name="eStatus" checked>
                            <label class="form-check-label" for="providerStatus">
                                Active Provider
                            </label>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Add Provider</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Provider Modal -->
<div class="modal fade" id="editProviderModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit Electricity Provider</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form id="editProviderForm">
                @csrf
                @method('PUT')
                <input type="hidden" id="editProviderId" name="provider_id">
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="editProviderPlan" class="form-label">Provider Name</label>
                        <input type="text" class="form-control" id="editProviderPlan" name="ePlan" required>
                    </div>

                    <div class="mb-3">
                        <label for="editProviderCode" class="form-label">Provider Code</label>
                        <input type="text" class="form-control" id="editProviderCode" name="eProviderId">
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="editBuyingPrice" class="form-label">Buying Price (₦/kWh)</label>
                                <input type="number" class="form-control" id="editBuyingPrice" name="eBuyingPrice" step="0.01" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="editSellingPrice" class="form-label">Selling Price (₦/kWh)</label>
                                <input type="number" class="form-control" id="editSellingPrice" name="ePrice" step="0.01" required>
                            </div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="editProviderStatus" name="eStatus">
                            <label class="form-check-label" for="editProviderStatus">
                                Active Provider
                            </label>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Update Provider</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection

@push('styles')
<link href="{{ asset('assets/vendor_components/dataTables/dataTables.bootstrap5.css') }}" rel="stylesheet">
@endpush

@push('scripts')
<script src="{{ asset('assets/vendor_components/dataTables/dataTables.min.js') }}"></script>
<script src="{{ asset('assets/vendor_components/dataTables/dataTables.bootstrap5.min.js') }}"></script>
<script src="{{ asset('assets/js/admin/electricity.js') }}"></script>
@endpush
