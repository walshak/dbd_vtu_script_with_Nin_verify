@extends('layouts.user-layout')

@php
    $title = 'Buy Data';
@endphp

@section('page-content')
<div class="container mx-auto px-6 py-8">
    <!-- Header Section -->
    <div class="mb-8">
        <div class="bg-gradient-to-r from-blue-500 to-purple-600 rounded-2xl shadow-lg p-8 text-white relative overflow-hidden">
            <div class="relative z-10">
                <div class="flex items-center justify-center mb-4">
                    <div class="bg-white bg-opacity-20 p-4 rounded-full">
                        <i class="fas fa-wifi text-4xl"></i>
                    </div>
                </div>
                <h1 class="text-3xl font-bold text-center mb-2">Buy Data</h1>
                <p class="text-blue-100 text-lg text-center">Purchase data bundles for any network</p>
            </div>
            <div class="absolute top-0 right-0 -mt-4 -mr-4 opacity-20">
                <i class="fas fa-signal text-9xl"></i>
            </div>
        </div>
    </div>

    <!-- Data Purchase Form -->
    <div class="max-w-2xl mx-auto">
        <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-8">
            <form id="data-form" class="space-y-6">
                @csrf
                <!-- Network Selection -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-4">Select Network</label>
                    <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <div class="network-option" data-network="mtn">
                            <input type="radio" id="mtn-data" name="network" value="mtn" class="sr-only">
                            <label for="mtn-data" class="network-label cursor-pointer block p-4 border-2 border-gray-200 rounded-xl text-center hover:border-yellow-300 hover:bg-yellow-50 transition-all duration-200">
                                <div class="bg-yellow-100 w-12 h-12 rounded-lg flex items-center justify-center mx-auto mb-3">
                                    <span class="text-yellow-600 font-bold text-lg">MTN</span>
                                </div>
                                <h3 class="font-medium text-gray-900 text-sm">MTN</h3>
                            </label>
                        </div>

                        <div class="network-option" data-network="glo">
                            <input type="radio" id="glo-data" name="network" value="glo" class="sr-only">
                            <label for="glo-data" class="network-label cursor-pointer block p-4 border-2 border-gray-200 rounded-xl text-center hover:border-green-300 hover:bg-green-50 transition-all duration-200">
                                <div class="bg-green-100 w-12 h-12 rounded-lg flex items-center justify-center mx-auto mb-3">
                                    <span class="text-green-600 font-bold text-lg">GLO</span>
                                </div>
                                <h3 class="font-medium text-gray-900 text-sm">Glo</h3>
                            </label>
                        </div>

                        <div class="network-option" data-network="airtel">
                            <input type="radio" id="airtel-data" name="network" value="airtel" class="sr-only">
                            <label for="airtel-data" class="network-label cursor-pointer block p-4 border-2 border-gray-200 rounded-xl text-center hover:border-red-300 hover:bg-red-50 transition-all duration-200">
                                <div class="bg-red-100 w-12 h-12 rounded-lg flex items-center justify-center mx-auto mb-3">
                                    <span class="text-red-600 font-bold text-sm">AIRTEL</span>
                                </div>
                                <h3 class="font-medium text-gray-900 text-sm">Airtel</h3>
                            </label>
                        </div>

                        <div class="network-option" data-network="9mobile">
                            <input type="radio" id="9mobile-data" name="network" value="9mobile" class="sr-only">
                            <label for="9mobile-data" class="network-label cursor-pointer block p-4 border-2 border-gray-200 rounded-xl text-center hover:border-green-300 hover:bg-green-50 transition-all duration-200">
                                <div class="bg-green-100 w-12 h-12 rounded-lg flex items-center justify-center mx-auto mb-3">
                                    <span class="text-green-600 font-bold text-sm">9MOB</span>
                                </div>
                                <h3 class="font-medium text-gray-900 text-sm">9mobile</h3>
                            </label>
                        </div>
                    </div>
                </div>

                <!-- Phone Number -->
                <div>
                    <label for="phone-data" class="block text-sm font-medium text-gray-700 mb-2">Phone Number</label>
                    <input type="tel"
                           id="phone-data"
                           name="phone"
                           class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                           placeholder="08012345678"
                           pattern="[0-9]{11}"
                           maxlength="11"
                           required>
                    <p class="text-sm text-gray-500 mt-1">Enter 11-digit phone number</p>
                </div>

                <!-- Data Plans -->
                <div id="data-plans-section" class="hidden">
                    <label class="block text-sm font-medium text-gray-700 mb-4">Select Data Plan</label>
                    <div id="data-plans-grid" class="grid grid-cols-1 md:grid-cols-2 gap-3">
                        <!-- Data plans will be loaded here -->
                    </div>
                </div>

                <input type="hidden" id="selected-plan" name="plan_id">

                <!-- Purchase Summary -->
                <div class="bg-gray-50 rounded-lg p-4 border border-gray-200">
                    <h3 class="text-sm font-medium text-gray-900 mb-3">Purchase Summary</h3>
                    <div class="space-y-2 text-sm">
                        <div class="flex justify-between">
                            <span class="text-gray-600">Network:</span>
                            <span class="font-medium" id="summary-network-data">Not selected</span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-600">Phone Number:</span>
                            <span class="font-medium" id="summary-phone-data">Not entered</span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-600">Data Plan:</span>
                            <span class="font-medium" id="summary-plan">Not selected</span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-600">Price:</span>
                            <span class="font-medium" id="summary-price">₦0.00</span>
                        </div>
                        <div class="border-t border-gray-200 pt-2 mt-2">
                            <div class="flex justify-between">
                                <span class="font-medium text-gray-900">You Pay:</span>
                                <span class="font-bold text-gray-900" id="summary-total-data">₦0.00</span>
                            </div>
                        </div>
                    </div>
                </div>

                <button type="submit"
                        id="purchase-data-btn"
                        class="w-full bg-gradient-to-r from-blue-500 to-purple-600 text-white font-semibold py-3 px-4 rounded-lg hover:from-blue-600 hover:to-purple-700 transition-all duration-300 transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed"
                        disabled>
                    <i class="fas fa-wifi mr-2"></i>Buy Data
                </button>
            </form>
        </div>
    </div>

    <!-- Recent Purchases -->
    <div class="max-w-2xl mx-auto mt-8">
        <div class="bg-white rounded-xl shadow-sm border border-gray-100">
            <div class="p-6 border-b border-gray-100">
                <h2 class="text-xl font-semibold text-gray-900">Recent Purchases</h2>
            </div>
            <div class="p-6">
                <div class="text-center py-12">
                    <div class="bg-gray-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                        <i class="fas fa-wifi text-gray-400 text-2xl"></i>
                    </div>
                    <h3 class="text-sm font-medium text-gray-900 mb-1">No purchases yet</h3>
                    <p class="text-sm text-gray-500">Your data purchase history will appear here</p>
                </div>
            </div>
        </div>
    </div>
</div>

@push('scripts')
<script>
$(document).ready(function() {
    let selectedNetwork = null;
    let selectedPlan = null;

    // Sample data plans for different networks
    const dataPlans = {
        'mtn': [
            { id: 'mtn_500mb', name: '500MB', price: 200, validity: '30 days' },
            { id: 'mtn_1gb', name: '1GB', price: 350, validity: '30 days' },
            { id: 'mtn_2gb', name: '2GB', price: 700, validity: '30 days' },
            { id: 'mtn_3gb', name: '3GB', price: 1000, validity: '30 days' },
            { id: 'mtn_5gb', name: '5GB', price: 1500, validity: '30 days' },
            { id: 'mtn_10gb', name: '10GB', price: 2500, validity: '30 days' }
        ],
        'glo': [
            { id: 'glo_500mb', name: '500MB', price: 150, validity: '14 days' },
            { id: 'glo_1gb', name: '1GB', price: 300, validity: '30 days' },
            { id: 'glo_2gb', name: '2GB', price: 600, validity: '30 days' },
            { id: 'glo_3gb', name: '3GB', price: 900, validity: '30 days' },
            { id: 'glo_5gb', name: '5GB', price: 1300, validity: '30 days' },
            { id: 'glo_10gb', name: '10GB', price: 2200, validity: '30 days' }
        ],
        'airtel': [
            { id: 'airtel_500mb', name: '500MB', price: 180, validity: '30 days' },
            { id: 'airtel_1gb', name: '1GB', price: 320, validity: '30 days' },
            { id: 'airtel_2gb', name: '2GB', price: 650, validity: '30 days' },
            { id: 'airtel_3gb', name: '3GB', price: 950, validity: '30 days' },
            { id: 'airtel_5gb', name: '5GB', price: 1400, validity: '30 days' },
            { id: 'airtel_10gb', name: '10GB', price: 2300, validity: '30 days' }
        ],
        '9mobile': [
            { id: '9mobile_500mb', name: '500MB', price: 160, validity: '30 days' },
            { id: '9mobile_1gb', name: '1GB', price: 310, validity: '30 days' },
            { id: '9mobile_2gb', name: '2GB', price: 620, validity: '30 days' },
            { id: '9mobile_3gb', name: '3GB', price: 900, validity: '30 days' },
            { id: '9mobile_5gb', name: '5GB', price: 1350, validity: '30 days' },
            { id: '9mobile_10gb', name: '10GB', price: 2250, validity: '30 days' }
        ]
    };

    // Network selection
    $('.network-option').click(function() {
        $('.network-option .network-label').removeClass('border-blue-500 bg-blue-50');
        $(this).find('.network-label').addClass('border-blue-500 bg-blue-50');

        selectedNetwork = $(this).data('network');
        $(this).find('input[type="radio"]').prop('checked', true);

        loadDataPlans();
        updateSummary();
    });

    function loadDataPlans() {
        if (!selectedNetwork) return;

        const plans = dataPlans[selectedNetwork];
        const planGrid = $('#data-plans-grid');
        planGrid.empty();

        plans.forEach(plan => {
            const planHtml = `
                <div class="plan-option cursor-pointer p-4 border-2 border-gray-200 rounded-lg hover:border-blue-300 hover:bg-blue-50 transition-all duration-200" data-plan-id="${plan.id}">
                    <div class="flex justify-between items-start mb-2">
                        <h4 class="font-semibold text-gray-900">${plan.name}</h4>
                        <span class="text-lg font-bold text-blue-600">₦${plan.price.toLocaleString()}</span>
                    </div>
                    <p class="text-sm text-gray-500">Valid for ${plan.validity}</p>
                </div>
            `;
            planGrid.append(planHtml);
        });

        $('#data-plans-section').removeClass('hidden');

        // Add click handlers to plan options
        $('.plan-option').click(function() {
            $('.plan-option').removeClass('border-blue-500 bg-blue-50');
            $(this).addClass('border-blue-500 bg-blue-50');

            const planId = $(this).data('plan-id');
            selectedPlan = plans.find(p => p.id === planId);
            $('#selected-plan').val(planId);

            updateSummary();
        });
    }

    // Phone number input
    $('#phone-data').on('input', function() {
        let phone = $(this).val().replace(/\D/g, '');
        if (phone.length > 11) {
            phone = phone.substr(0, 11);
        }
        $(this).val(phone);
        updateSummary();
    });

    function updateSummary() {
        const phone = $('#phone-data').val();

        // Update summary display
        $('#summary-network-data').text(selectedNetwork ? selectedNetwork.toUpperCase() : 'Not selected');
        $('#summary-phone-data').text(phone || 'Not entered');

        if (selectedPlan) {
            $('#summary-plan').text(`${selectedPlan.name} (${selectedPlan.validity})`);
            $('#summary-price').text('₦' + selectedPlan.price.toLocaleString());
            $('#summary-total-data').text('₦' + selectedPlan.price.toLocaleString());
        } else {
            $('#summary-plan').text('Not selected');
            $('#summary-price').text('₦0.00');
            $('#summary-total-data').text('₦0.00');
        }

        // Enable/disable purchase button
        const canPurchase = selectedNetwork && phone.length === 11 && selectedPlan;
        $('#purchase-data-btn').prop('disabled', !canPurchase);
    }

    // Form submission
    $('#data-form').submit(function(e) {
        e.preventDefault();

        if (!selectedNetwork || !selectedPlan) {
            Swal.fire({
                icon: 'warning',
                title: 'Incomplete Selection',
                text: 'Please select network and data plan',
                confirmButtonColor: '#F59E0B'
            });
            return;
        }

        const phone = $('#phone-data').val();
        if (phone.length !== 11) {
            Swal.fire({
                icon: 'warning',
                title: 'Invalid Phone Number',
                text: 'Please enter a valid 11-digit phone number',
                confirmButtonColor: '#F59E0B'
            });
            return;
        }

        // Show confirmation dialog
        Swal.fire({
            icon: 'question',
            title: 'Confirm Purchase',
            html: `
                <div class="text-left">
                    <p><strong>Network:</strong> ${selectedNetwork.toUpperCase()}</p>
                    <p><strong>Phone:</strong> ${phone}</p>
                    <p><strong>Data Plan:</strong> ${selectedPlan.name} (${selectedPlan.validity})</p>
                    <p><strong>Price:</strong> ₦${selectedPlan.price.toLocaleString()}</p>
                </div>
            `,
            showCancelButton: true,
            confirmButtonText: 'Buy Now',
            cancelButtonText: 'Cancel',
            confirmButtonColor: '#3B82F6'
        }).then((result) => {
            if (result.isConfirmed) {
                // Simulate purchase process
                Swal.fire({
                    icon: 'info',
                    title: 'Processing Purchase',
                    text: 'Data purchase functionality will be implemented here',
                    confirmButtonColor: '#3B82F6'
                });
            }
        });
    });
});
</script>
@endpush
@endsection
