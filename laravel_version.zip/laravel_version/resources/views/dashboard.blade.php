@extends('layouts.user-layout')

@php
    $title = 'Dashboard';
@endphp

@section('page-content')
            <div class="container mx-auto px-6 py-8">
                <!-- Welcome Section -->
                <div class="mb-8">
                    <div class="bg-gradient-to-r from-blue-500 to-purple-600 rounded-2xl shadow-lg p-8 text-white relative overflow-hidden">
                        <div class="relative z-10">
                            <h1 class="text-3xl font-bold mb-2">Welcome back, {{ auth()->user()->sFname ?? 'User' }}!</h1>
                            <p class="text-blue-100 text-lg">Manage your VTU services and track your transactions</p>
                        </div>
                        <div class="absolute top-0 right-0 -mt-4 -mr-4 opacity-20">
                            <i class="fas fa-mobile-alt text-9xl"></i>
                        </div>
                    </div>
                </div>

                <!-- Stats Cards -->
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                    <!-- Wallet Balance -->
                    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6 hover:shadow-md transition-shadow">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-sm font-medium text-gray-500 mb-1">Wallet Balance</p>
                                <p class="text-2xl font-bold text-gray-900">₦{{ number_format(auth()->user()->sWallet ?? 0, 2) }}</p>
                                <p class="text-xs text-green-600 mt-1">
                                    <i class="fas fa-arrow-up mr-1"></i>Available
                                </p>
                            </div>
                            <div class="bg-green-100 p-3 rounded-full">
                                <i class="fas fa-wallet text-green-600 text-xl"></i>
                            </div>
                        </div>
                    </div>

                    <!-- Total Transactions -->
                    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6 hover:shadow-md transition-shadow">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-sm font-medium text-gray-500 mb-1">Total Transactions</p>
                                <p class="text-2xl font-bold text-gray-900">0</p>
                                <p class="text-xs text-blue-600 mt-1">
                                    <i class="fas fa-chart-line mr-1"></i>This month
                                </p>
                            </div>
                            <div class="bg-blue-100 p-3 rounded-full">
                                <i class="fas fa-exchange-alt text-blue-600 text-xl"></i>
                            </div>
                        </div>
                    </div>

                    <!-- Account Type -->
                    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6 hover:shadow-md transition-shadow">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-sm font-medium text-gray-500 mb-1">Account Type</p>
                                <p class="text-2xl font-bold text-gray-900">{{ auth()->user()->sType == 1 ? 'User' : (auth()->user()->sType == 2 ? 'Agent' : 'Vendor') }}</p>
                                <p class="text-xs text-purple-600 mt-1">
                                    <i class="fas fa-user-tag mr-1"></i>Active
                                </p>
                            </div>
                            <div class="bg-purple-100 p-3 rounded-full">
                                <i class="fas fa-users text-purple-600 text-xl"></i>
                            </div>
                        </div>
                    </div>

                    <!-- Member Since -->
                    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6 hover:shadow-md transition-shadow">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-sm font-medium text-gray-500 mb-1">Member Since</p>
                                <p class="text-2xl font-bold text-gray-900">{{ auth()->user()->created_at->format('M Y') }}</p>
                                <p class="text-xs text-orange-600 mt-1">
                                    <i class="fas fa-calendar mr-1"></i>{{ auth()->user()->created_at->diffForHumans() }}
                                </p>
                            </div>
                            <div class="bg-orange-100 p-3 rounded-full">
                                <i class="fas fa-calendar-alt text-orange-600 text-xl"></i>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Quick Actions Grid -->
                <div class="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
                    <!-- Quick Services -->
                    <div class="lg:col-span-2">
                        <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                            <div class="flex items-center justify-between mb-6">
                                <h2 class="text-xl font-semibold text-gray-900">Quick Services</h2>
                                <span class="text-sm text-gray-500">Most used services</span>
                            </div>

                            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                                <!-- Airtime -->
                                <a href="/buy-airtime" class="service-btn group p-4 rounded-xl border border-gray-200 hover:border-green-300 hover:bg-green-50 transition-all duration-200 text-center">
                                    <div class="bg-green-100 w-12 h-12 rounded-lg flex items-center justify-center mx-auto mb-3 group-hover:bg-green-200 transition-colors">
                                        <i class="fas fa-mobile-alt text-green-600 text-xl"></i>
                                    </div>
                                    <h3 class="font-medium text-gray-900 text-sm">Buy Airtime</h3>
                                    <p class="text-xs text-gray-500 mt-1">All networks</p>
                                </a>

                                <!-- Data -->
                                <a href="/buy-data" class="service-btn group p-4 rounded-xl border border-gray-200 hover:border-blue-300 hover:bg-blue-50 transition-all duration-200 text-center">
                                    <div class="bg-blue-100 w-12 h-12 rounded-lg flex items-center justify-center mx-auto mb-3 group-hover:bg-blue-200 transition-colors">
                                        <i class="fas fa-wifi text-blue-600 text-xl"></i>
                                    </div>
                                    <h3 class="font-medium text-gray-900 text-sm">Buy Data</h3>
                                    <p class="text-xs text-gray-500 mt-1">Internet bundles</p>
                                </a>

                                <!-- Cable TV -->
                                <a href="/cable-tv" class="service-btn group p-4 rounded-xl border border-gray-200 hover:border-purple-300 hover:bg-purple-50 transition-all duration-200 text-center">
                                    <div class="bg-purple-100 w-12 h-12 rounded-lg flex items-center justify-center mx-auto mb-3 group-hover:bg-purple-200 transition-colors">
                                        <i class="fas fa-tv text-purple-600 text-xl"></i>
                                    </div>
                                    <h3 class="font-medium text-gray-900 text-sm">Cable TV</h3>
                                    <p class="text-xs text-gray-500 mt-1">DSTV, GOTV</p>
                                </a>

                                <!-- Electricity -->
                                <a href="/electricity" class="service-btn group p-4 rounded-xl border border-gray-200 hover:border-yellow-300 hover:bg-yellow-50 transition-all duration-200 text-center">
                                    <div class="bg-yellow-100 w-12 h-12 rounded-lg flex items-center justify-center mx-auto mb-3 group-hover:bg-yellow-200 transition-colors">
                                        <i class="fas fa-bolt text-yellow-600 text-xl"></i>
                                    </div>
                                    <h3 class="font-medium text-gray-900 text-sm">Electricity</h3>
                                    <p class="text-xs text-gray-500 mt-1">Pay bills</p>
                                </a>
                            </div>
                        </div>
                    </div>

                    <!-- Quick Fund Wallet -->
                    <div class="space-y-6">
                        <!-- Fund Wallet Card -->
                        <div class="bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl shadow-lg p-6 text-white">
                            <div class="flex items-center justify-between mb-4">
                                <h3 class="text-lg font-semibold">Fund Wallet</h3>
                                <i class="fas fa-credit-card text-2xl opacity-75"></i>
                            </div>
                            <p class="text-indigo-100 text-sm mb-4">Add money to your wallet securely using bank transfer or card payment</p>
                            <a href="/fund-wallet" id="fund-wallet-btn" class="block w-full bg-white text-indigo-600 font-semibold py-2 px-4 rounded-lg hover:bg-gray-50 transition-colors text-center">
                                <i class="fas fa-plus mr-2"></i>Add Funds
                            </a>
                        </div>

                        <!-- Account Summary -->
                        <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                            <h3 class="text-lg font-semibold text-gray-900 mb-4">Account Summary</h3>
                            <div class="space-y-3">
                                <div class="flex justify-between items-center">
                                    <span class="text-sm text-gray-600">Phone Number</span>
                                    <span class="text-sm font-medium">{{ auth()->user()->sPhone ?? 'N/A' }}</span>
                                </div>
                                <div class="flex justify-between items-center">
                                    <span class="text-sm text-gray-600">Email</span>
                                    <span class="text-sm font-medium">{{ auth()->user()->sEmail ?? 'N/A' }}</span>
                                </div>
                                <div class="flex justify-between items-center">
                                    <span class="text-sm text-gray-600">Status</span>
                                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                        Active
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Recent Transactions and Notifications -->
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    <!-- Recent Transactions -->
                    <div class="bg-white rounded-xl shadow-sm border border-gray-100">
                        <div class="p-6 border-b border-gray-100">
                            <div class="flex items-center justify-between">
                                <h2 class="text-xl font-semibold text-gray-900">Recent Transactions</h2>
                                <a href="#" class="text-sm text-blue-600 hover:text-blue-500 font-medium">View all</a>
                            </div>
                        </div>
                        <div class="p-6">
                            <div class="text-center py-12">
                                <div class="bg-gray-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                                    <i class="fas fa-receipt text-gray-400 text-2xl"></i>
                                </div>
                                <h3 class="text-sm font-medium text-gray-900 mb-1">No transactions yet</h3>
                                <p class="text-sm text-gray-500">Your transaction history will appear here</p>
                                <button class="mt-4 text-blue-600 hover:text-blue-500 text-sm font-medium">
                                    Make your first transaction
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Notifications & Updates -->
                    <div class="bg-white rounded-xl shadow-sm border border-gray-100">
                        <div class="p-6 border-b border-gray-100">
                            <div class="flex items-center justify-between">
                                <h2 class="text-xl font-semibold text-gray-900">Notifications</h2>
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                    3 new
                                </span>
                            </div>
                        </div>
                        <div class="p-6">
                            <div class="space-y-4">
                                <div class="flex items-start space-x-3">
                                    <div class="bg-blue-100 p-2 rounded-full">
                                        <i class="fas fa-info-circle text-blue-600 text-sm"></i>
                                    </div>
                                    <div class="flex-1">
                                        <h4 class="text-sm font-medium text-gray-900">Welcome to VASTLEAD </h4>
                                        <p class="text-sm text-gray-500 mt-1">Complete your profile to get started with our services.</p>
                                        <span class="text-xs text-gray-400">2 hours ago</span>
                                    </div>
                                </div>

                                <div class="flex items-start space-x-3">
                                    <div class="bg-green-100 p-2 rounded-full">
                                        <i class="fas fa-check-circle text-green-600 text-sm"></i>
                                    </div>
                                    <div class="flex-1">
                                        <h4 class="text-sm font-medium text-gray-900">Account Verified</h4>
                                        <p class="text-sm text-gray-500 mt-1">Your account has been successfully verified.</p>
                                        <span class="text-xs text-gray-400">1 day ago</span>
                                    </div>
                                </div>

                                <div class="flex items-start space-x-3">
                                    <div class="bg-purple-100 p-2 rounded-full">
                                        <i class="fas fa-gift text-purple-600 text-sm"></i>
                                    </div>
                                    <div class="flex-1">
                                        <h4 class="text-sm font-medium text-gray-900">Welcome Bonus</h4>
                                        <p class="text-sm text-gray-500 mt-1">Enjoy special rates on your first transactions!</p>
                                        <span class="text-xs text-gray-400">2 days ago</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>

@push('scripts')
<script>
$(document).ready(function() {
    // Service button clicks with links
    $('.service-btn').click(function(e) {
        e.preventDefault();
        const href = $(this).data('href');
        if (href) {
            window.location.href = href;
        }
    });

    // Fund wallet button
    $('#fund-wallet-btn').click(function() {
        window.location.href = '/fund-wallet';
    });

    // Sidebar link hover effects
    $('.group').hover(
        function() {
            $(this).find('i').addClass('transform scale-110');
        },
        function() {
            $(this).find('i').removeClass('transform scale-110');
        }
    );

    // Add smooth transitions to cards
    $('.hover\\:shadow-md').hover(
        function() {
            $(this).addClass('transform scale-105');
        },
        function() {
            $(this).removeClass('transform scale-105');
        }
    );
});
</script>
@endpush
@endsection
