<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class AdminSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Check if admin already exists
        $existingAdmin = DB::table('sysusers')->where('sysUsername', 'walshak1999@gmail.com')->first();

        if (!$existingAdmin) {
            DB::table('sysusers')->insert([
                'sysName' => 'Admin User',
                'sysUsername' => 'walshak1999@gmail.com',
                'sysToken' => Hash::make('12345678'),
                'sysRole' => 1, // 1 for admin/super admin role
                'sysStatus' => 1, // 1 for active status
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
            ]);

            $this->command->info('Admin user created successfully!');
            $this->command->info('Email: walshak1999@gmail.com');
            $this->command->info('Password: 12345678');
        } else {
            $this->command->info('Admin user already exists!');
        }
    }
}
