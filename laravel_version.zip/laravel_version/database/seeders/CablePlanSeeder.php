<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\CablePlan;

class CablePlanSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $cablePlans = [
            // DSTV Plans
            ['cPlanId' => 'dstv-padi', 'cDecoder' => 'dstv', 'cPlan' => 'DStv Padi', 'userPrice' => 2150, 'agentPrice' => 2100, 'apiPrice' => 2050, 'cDuration' => 'Monthly'],
            ['cPlanId' => 'dstv-yanga', 'cDecoder' => 'dstv', 'cPlan' => 'DStv Yanga', 'userPrice' => 2950, 'agentPrice' => 2900, 'apiPrice' => 2850, 'cDuration' => 'Monthly'],
            ['cPlanId' => 'dstv-confam', 'cDecoder' => 'dstv', 'cPlan' => 'DStv Confam', 'userPrice' => 5300, 'agentPrice' => 5200, 'apiPrice' => 5100, 'cDuration' => 'Monthly'],
            ['cPlanId' => 'dstv-compact', 'cDecoder' => 'dstv', 'cPlan' => 'DStv Compact', 'userPrice' => 9000, 'agentPrice' => 8900, 'apiPrice' => 8800, 'cDuration' => 'Monthly'],
            ['cPlanId' => 'dstv-compact-plus', 'cDecoder' => 'dstv', 'cPlan' => 'DStv Compact Plus', 'userPrice' => 14250, 'agentPrice' => 14100, 'apiPrice' => 14000, 'cDuration' => 'Monthly'],
            ['cPlanId' => 'dstv-premium', 'cDecoder' => 'dstv', 'cPlan' => 'DStv Premium', 'userPrice' => 21000, 'agentPrice' => 20800, 'apiPrice' => 20600, 'cDuration' => 'Monthly'],

            // GOtv Plans
            ['cPlanId' => 'gotv-smallie', 'cDecoder' => 'gotv', 'cPlan' => 'GOtv Smallie', 'userPrice' => 900, 'agentPrice' => 880, 'apiPrice' => 860, 'cDuration' => 'Monthly'],
            ['cPlanId' => 'gotv-jinja', 'cDecoder' => 'gotv', 'cPlan' => 'GOtv Jinja', 'userPrice' => 1900, 'agentPrice' => 1850, 'apiPrice' => 1800, 'cDuration' => 'Monthly'],
            ['cPlanId' => 'gotv-jolli', 'cDecoder' => 'gotv', 'cPlan' => 'GOtv Jolli', 'userPrice' => 2800, 'agentPrice' => 2750, 'apiPrice' => 2700, 'cDuration' => 'Monthly'],
            ['cPlanId' => 'gotv-max', 'cDecoder' => 'gotv', 'cPlan' => 'GOtv Max', 'userPrice' => 4150, 'agentPrice' => 4100, 'apiPrice' => 4050, 'cDuration' => 'Monthly'],
            ['cPlanId' => 'gotv-supa', 'cDecoder' => 'gotv', 'cPlan' => 'GOtv Supa', 'userPrice' => 5500, 'agentPrice' => 5400, 'apiPrice' => 5300, 'cDuration' => 'Monthly'],

            // Startimes Plans
            ['cPlanId' => 'startimes-nova', 'cDecoder' => 'startimes', 'cPlan' => 'Startimes Nova', 'userPrice' => 900, 'agentPrice' => 880, 'apiPrice' => 860, 'cDuration' => 'Monthly'],
            ['cPlanId' => 'startimes-basic', 'cDecoder' => 'startimes', 'cPlan' => 'Startimes Basic', 'userPrice' => 1850, 'agentPrice' => 1800, 'apiPrice' => 1750, 'cDuration' => 'Monthly'],
            ['cPlanId' => 'startimes-smart', 'cDecoder' => 'startimes', 'cPlan' => 'Startimes Smart', 'userPrice' => 2480, 'agentPrice' => 2400, 'apiPrice' => 2350, 'cDuration' => 'Monthly'],
            ['cPlanId' => 'startimes-classic', 'cDecoder' => 'startimes', 'cPlan' => 'Startimes Classic', 'userPrice' => 2750, 'agentPrice' => 2700, 'apiPrice' => 2650, 'cDuration' => 'Monthly'],
            ['cPlanId' => 'startimes-super', 'cDecoder' => 'startimes', 'cPlan' => 'Startimes Super', 'userPrice' => 4200, 'agentPrice' => 4100, 'apiPrice' => 4000, 'cDuration' => 'Monthly'],
        ];

        foreach ($cablePlans as $plan) {
            CablePlan::updateOrCreate(
                ['cPlanId' => $plan['cPlanId']],
                $plan
            );
        }
    }
}
