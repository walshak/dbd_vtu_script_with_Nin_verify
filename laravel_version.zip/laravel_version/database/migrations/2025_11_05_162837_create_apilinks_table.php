<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('apilinks', function (Blueprint $table) {
            $table->id('aId');
            $table->string('name', 30)->nullable();
            $table->string('value', 100)->nullable();
            $table->string('type', 20)->nullable();
            $table->boolean('is_active')->default(true);
            $table->integer('priority')->default(1);
            $table->decimal('success_rate', 5, 2)->default(100.00);
            $table->integer('response_time')->default(0); // in milliseconds
            $table->datetime('last_checked')->nullable();
            $table->timestamps();
            
            $table->index(['type', 'is_active']);
            $table->index(['priority', 'success_rate']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('apilinks');
    }
};
