<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('api_links', function (Blueprint $table) {
            $table->id();
            $table->string('name'); // Provider name (e.g., "N3TDATA", "BilalSadaSub")
            $table->string('type'); // Service type (Airtime, Data, Cable, Electricity, etc.)
            $table->text('value'); // API endpoint URL
            $table->string('auth_type')->default('token'); // token, basic, access_token
            $table->json('auth_params')->nullable(); // Additional auth parameters
            $table->boolean('is_active')->default(true);
            $table->integer('priority')->default(1); // For failover ordering
            $table->timestamps();

            $table->index(['type', 'is_active']);
            $table->index('priority');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('api_links');
    }
};
