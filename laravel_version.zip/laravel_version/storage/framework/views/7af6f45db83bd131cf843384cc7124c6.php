

<?php $__env->startSection('title', 'Electricity Bill Payment'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <!-- Header -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h1 class="h3 mb-0 text-gray-800">
                        <i class="fas fa-bolt text-warning"></i> Electricity Bill Payment
                    </h1>
                    <p class="text-muted">Purchase electricity tokens for all major Nigerian DISCOs</p>
                </div>
                <div>
                    <span class="badge badge-success fs-6">
                        <i class="fas fa-wallet"></i> ₦<?php echo e(number_format(auth()->user()->sWallet, 2)); ?>

                    </span>
                </div>
            </div>
        </div>
    </div>

    <?php if($maintenanceMode): ?>
    <div class="alert alert-warning alert-dismissible fade show" role="alert">
        <i class="fas fa-exclamation-triangle"></i>
        <strong>Maintenance Notice:</strong> <?php echo e($maintenanceMessage); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>

    <div class="row">
        <!-- Payment Form -->
        <div class="col-lg-8">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">
                        <i class="fas fa-credit-card"></i> Purchase Electricity Token
                    </h6>
                </div>
                <div class="card-body">
                    <form id="electricityForm" class="needs-validation" novalidate>
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="provider" class="form-label">
                                        <i class="fas fa-building"></i> Select Electricity Provider
                                    </label>
                                    <select class="form-select" id="provider" name="provider" required>
                                        <option value="">Choose your DISCO...</option>
                                        <?php $__currentLoopData = $providers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($provider->ePlan); ?>" 
                                                data-rate="<?php echo e($provider->ePrice); ?>"
                                                data-charges="<?php echo e($serviceCharges); ?>">
                                            <?php echo e(strtoupper($provider->ePlan)); ?> - ₦<?php echo e(number_format($provider->ePrice, 2)); ?>/kWh
                                        </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <div class="invalid-feedback">
                                        Please select an electricity provider.
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="meterType" class="form-label">
                                        <i class="fas fa-tachometer-alt"></i> Meter Type
                                    </label>
                                    <select class="form-select" id="meterType" name="meter_type" required>
                                        <option value="">Select meter type...</option>
                                        <option value="prepaid">Prepaid Meter</option>
                                        <option value="postpaid">Postpaid Meter</option>
                                    </select>
                                    <div class="invalid-feedback">
                                        Please select your meter type.
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="meterNumber" class="form-label">
                                        <i class="fas fa-hashtag"></i> Meter Number
                                    </label>
                                    <input type="text" class="form-control" id="meterNumber" name="meter_number" 
                                           placeholder="Enter your meter number" required>
                                    <div class="invalid-feedback">
                                        Please enter a valid meter number.
                                    </div>
                                    <div class="form-text">
                                        <i class="fas fa-info-circle"></i> Enter your 11-digit meter number
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="amount" class="form-label">
                                        <i class="fas fa-naira-sign"></i> Amount (₦)
                                    </label>
                                    <input type="number" class="form-control" id="amount" name="amount" 
                                           placeholder="Enter amount" min="<?php echo e($minimumAmount); ?>" 
                                           max="<?php echo e($maximumAmount); ?>" required>
                                    <div class="invalid-feedback">
                                        Amount must be between ₦<?php echo e(number_format($minimumAmount)); ?> and ₦<?php echo e(number_format($maximumAmount)); ?>.
                                    </div>
                                    <div class="form-text">
                                        <i class="fas fa-info-circle"></i> Min: ₦<?php echo e(number_format($minimumAmount)); ?> | Max: ₦<?php echo e(number_format($maximumAmount)); ?>

                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Customer Information (populated after validation) -->
                        <div id="customerInfo" class="alert alert-info" style="display: none;">
                            <h6><i class="fas fa-user"></i> Customer Information</h6>
                            <div class="row">
                                <div class="col-md-6">
                                    <strong>Customer Name:</strong> <span id="customerName">-</span>
                                </div>
                                <div class="col-md-6">
                                    <strong>Meter Type:</strong> <span id="customerMeterType">-</span>
                                </div>
                            </div>
                        </div>

                        <!-- Transaction Summary -->
                        <div id="transactionSummary" class="card bg-light mb-3" style="display: none;">
                            <div class="card-body">
                                <h6 class="card-title"><i class="fas fa-calculator"></i> Transaction Summary</h6>
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="text-center">
                                            <div class="text-muted">Amount</div>
                                            <div class="h5 text-primary" id="summaryAmount">₦0.00</div>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="text-center">
                                            <div class="text-muted">Service Charge</div>
                                            <div class="h5 text-warning" id="summaryCharges">₦0.00</div>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="text-center">
                                            <div class="text-muted">Total</div>
                                            <div class="h5 text-success" id="summaryTotal">₦0.00</div>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="text-center">
                                            <div class="text-muted">Units (Estimated)</div>
                                            <div class="h5 text-info" id="summaryUnits">0 kWh</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-12">
                                <button type="button" class="btn btn-outline-primary me-2" id="validateMeterBtn">
                                    <i class="fas fa-check-circle"></i> Validate Meter
                                </button>
                                
                                <button type="submit" class="btn btn-primary" id="purchaseBtn" disabled>
                                    <i class="fas fa-shopping-cart"></i> Purchase Token
                                </button>
                                
                                <button type="button" class="btn btn-secondary ms-2" id="resetFormBtn">
                                    <i class="fas fa-refresh"></i> Reset
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Sidebar -->
        <div class="col-lg-4">
            <!-- Quick Info Card -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">
                        <i class="fas fa-info-circle"></i> Quick Information
                    </h6>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <h6><i class="fas fa-clock"></i> Service Hours</h6>
                        <p class="text-muted mb-0">24/7 Available</p>
                    </div>
                    
                    <div class="mb-3">
                        <h6><i class="fas fa-shield-alt"></i> Secure Payment</h6>
                        <p class="text-muted mb-0">Your transactions are protected with bank-level security</p>
                    </div>
                    
                    <div class="mb-3">
                        <h6><i class="fas fa-mobile-alt"></i> Instant Delivery</h6>
                        <p class="text-muted mb-0">Tokens delivered instantly via SMS and email</p>
                    </div>

                    <div class="mb-3">
                        <h6><i class="fas fa-headset"></i> Support</h6>
                        <p class="text-muted mb-0">24/7 customer support available</p>
                    </div>
                </div>
            </div>

            <!-- Available Providers -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">
                        <i class="fas fa-plug"></i> Available Providers
                    </h6>
                </div>
                <div class="card-body">
                    <div class="row">
                        <?php $__currentLoopData = $providers->chunk(2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $providerPair): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $providerPair; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-6 mb-2">
                            <div class="provider-card p-2 border rounded text-center" 
                                 data-provider="<?php echo e($provider->ePlan); ?>"
                                 data-rate="<?php echo e($provider->ePrice); ?>">
                                <img src="<?php echo e($provider->logo_path); ?>" alt="<?php echo e($provider->ePlan); ?>" 
                                     class="provider-logo mb-1" width="30" height="30">
                                <div class="small"><strong><?php echo e(strtoupper($provider->ePlan)); ?></strong></div>
                                <div class="text-muted small">₦<?php echo e(number_format($provider->ePrice, 2)); ?>/kWh</div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>

            <!-- Recent Transactions -->
            <div class="card shadow">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">
                        <i class="fas fa-history"></i> Recent Transactions
                    </h6>
                </div>
                <div class="card-body">
                    <?php if($recentTransactions->count() > 0): ?>
                    <?php $__currentLoopData = $recentTransactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="d-flex justify-content-between align-items-center border-bottom py-2">
                        <div>
                            <div class="font-weight-bold"><?php echo e($transaction->extractProvider()); ?></div>
                            <div class="small text-muted"><?php echo e($transaction->extractMeterNumber()); ?></div>
                        </div>
                        <div class="text-end">
                            <div class="font-weight-bold">₦<?php echo e(number_format($transaction->amount, 2)); ?></div>
                            <div class="small">
                                <span class="badge <?php echo e($transaction->status_badge_class); ?>">
                                    <?php echo e($transaction->status_text); ?>

                                </span>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="text-center mt-3">
                        <a href="<?php echo e(route('electricity.history')); ?>" class="btn btn-sm btn-outline-primary">
                            View All Transactions
                        </a>
                    </div>
                    <?php else: ?>
                    <div class="text-center text-muted">
                        <i class="fas fa-inbox fa-2x mb-2"></i>
                        <p>No recent transactions</p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Transaction PIN Modal -->
<div class="modal fade" id="transactionPinModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-lock"></i> Enter Transaction PIN
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p>Please enter your 4-digit transaction PIN to complete this purchase:</p>
                
                <div class="mb-3">
                    <label for="transactionPin" class="form-label">Transaction PIN</label>
                    <input type="password" class="form-control text-center" id="transactionPin" 
                           maxlength="4" placeholder="****" style="font-size: 1.5rem; letter-spacing: 0.5rem;">
                    <div class="form-text">
                        <i class="fas fa-info-circle"></i> Enter your 4-digit transaction PIN
                    </div>
                </div>
                
                <div class="alert alert-info">
                    <strong>Transaction Details:</strong><br>
                    Provider: <span id="confirmProvider">-</span><br>
                    Meter Number: <span id="confirmMeterNumber">-</span><br>
                    Amount: <span id="confirmAmount">-</span><br>
                    Total: <span id="confirmTotal">-</span>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" id="confirmPurchaseBtn">
                    <i class="fas fa-check"></i> Confirm Purchase
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Success Modal -->
<div class="modal fade" id="successModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-success text-white">
                <h5 class="modal-title">
                    <i class="fas fa-check-circle"></i> Purchase Successful
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="text-center mb-3">
                    <i class="fas fa-check-circle text-success" style="font-size: 4rem;"></i>
                </div>
                
                <div class="alert alert-success">
                    <h6>Transaction Successful!</h6>
                    <div class="transaction-details">
                        <strong>Reference:</strong> <span id="successReference">-</span><br>
                        <strong>Provider:</strong> <span id="successProvider">-</span><br>
                        <strong>Meter Number:</strong> <span id="successMeterNumber">-</span><br>
                        <strong>Amount:</strong> <span id="successAmount">-</span><br>
                        <strong>Token:</strong> <span id="successToken" class="text-primary font-weight-bold">-</span><br>
                        <strong>Units:</strong> <span id="successUnits">-</span>
                    </div>
                </div>
                
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i>
                    Your electricity token has been sent to your registered phone number via SMS.
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" id="printReceiptBtn">
                    <i class="fas fa-print"></i> Print Receipt
                </button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
.provider-card {
    cursor: pointer;
    transition: all 0.3s ease;
}

.provider-card:hover {
    background-color: #f8f9fa;
    border-color: #007bff !important;
    transform: translateY(-2px);
}

.provider-card.selected {
    background-color: #e3f2fd;
    border-color: #2196f3 !important;
    border-width: 2px !important;
}

.provider-logo {
    object-fit: contain;
}

.card {
    border: none;
    border-radius: 10px;
}

.card-header {
    border-radius: 10px 10px 0 0 !important;
}

#transactionPin {
    background-color: #f8f9fa;
}

.transaction-details {
    line-height: 1.8;
}

@media (max-width: 768px) {
    .container-fluid {
        padding: 15px;
    }
    
    .provider-card {
        margin-bottom: 10px;
    }
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('assets/js/electricity.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\MrApollos\Documents\work\dbd_vtu_script_with_Nin_verify\laravel_version\resources\views/electricity/index.blade.php ENDPATH**/ ?>