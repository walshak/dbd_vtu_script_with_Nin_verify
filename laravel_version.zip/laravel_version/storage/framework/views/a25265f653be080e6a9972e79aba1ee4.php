<?php $__env->startSection('title', 'API Configuration - General Settings'); ?>
<?php $__env->startSection('page-title', 'API Configuration'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between mb-4">
    <a class="btn btn-success me-2" href="<?php echo e(route('admin.api-configuration.index')); ?>">General Setting</a>
    <a class="btn btn-primary me-2" href="<?php echo e(route('admin.system.wallet-providers.monnify')); ?>">Monnify Setting</a>
    <a class="btn btn-info" href="<?php echo e(route('admin.system.wallet-providers.paystack')); ?>">Paystack Setting</a>
</div>

<div class="d-flex justify-content-between mb-4">
    <a class="btn btn-dark btn-sm me-2" href="<?php echo e(route('admin.api-configuration.index')); ?>">General</a>
    <a class="btn btn-dark btn-sm me-2" href="<?php echo e(route('admin.api-configuration.airtime')); ?>">Airtime</a>
    <a class="btn btn-dark btn-sm me-2" href="<?php echo e(route('admin.api-configuration.data')); ?>">Data</a>
    <a class="btn btn-dark btn-sm" href="<?php echo e(route('admin.api-configuration.wallet')); ?>">Wallet</a>
</div>

<div class="row">
    <div class="col-12">
        <div class="box">
            <div class="box-header with-border">
                <h4 class="box-title">Manage API Settings</h4>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
                <form method="post" action="<?php echo e(route('admin.api-configuration.update-general')); ?>" class="form-submit">
                    <?php echo csrf_field(); ?>

                    <!-- Cable TV Configuration -->
                    <div class="form-group mb-4">
                        <label for="cableVerificationApi" class="control-label font-medium">Cable Api Key</label>
                        <div class="">
                            <input type="text" name="cableVerificationApi"
                                   value="<?php echo e($configs->get('cableVerificationApi')->value ?? ''); ?>"
                                   class="form-control w-full px-3 py-2 border border-gray-300 rounded-md">
                        </div>
                    </div>

                    <div class="form-group mb-4">
                        <label for="cableVerificationProvider" class="control-label font-medium">Cable TV IUC Verification Url</label>
                        <div class="">
                            <select name="cableVerificationProvider" class="form-control w-full px-3 py-2 border border-gray-300 rounded-md" required>
                                <option value="">Select Api Provider</option>
                                <?php $cableVerificationProvider = $configs->get('cableVerificationProvider')->value ?? ''; ?>
                                <?php $__currentLoopData = $apiLinks->get('CableVer', collect()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $apiLink): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($apiLink->value); ?>"
                                            <?php echo e($cableVerificationProvider == $apiLink->value ? 'selected' : ''); ?>>
                                        <?php echo e($apiLink->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group mb-4">
                        <label for="cableApi" class="control-label font-medium">Cable Api Key</label>
                        <div class="">
                            <input type="text" name="cableApi"
                                   value="<?php echo e($configs->get('cableApi')->value ?? ''); ?>"
                                   class="form-control w-full px-3 py-2 border border-gray-300 rounded-md">
                        </div>
                    </div>

                    <div class="form-group mb-4">
                        <label for="cableProvider" class="control-label font-medium">Cable TV API Url</label>
                        <div class="">
                            <select name="cableProvider" class="form-control w-full px-3 py-2 border border-gray-300 rounded-md" required>
                                <option value="">Select Api Provider</option>
                                <?php $cableProvider = $configs->get('cableProvider')->value ?? ''; ?>
                                <?php $__currentLoopData = $apiLinks->get('Cable', collect()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $apiLink): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($apiLink->value); ?>"
                                            <?php echo e($cableProvider == $apiLink->value ? 'selected' : ''); ?>>
                                        <?php echo e($apiLink->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <!-- Electricity Configuration -->
                    <div class="form-group mb-4">
                        <label for="meterVerificationApi" class="control-label font-medium">Electricity Meter Api Key</label>
                        <div class="">
                            <input type="text" name="meterVerificationApi"
                                   value="<?php echo e($configs->get('meterVerificationApi')->value ?? ''); ?>"
                                   class="form-control w-full px-3 py-2 border border-gray-300 rounded-md">
                        </div>
                    </div>

                    <div class="form-group mb-4">
                        <label for="meterVerificationProvider" class="control-label font-medium">Electricity Meter Verification Url</label>
                        <div class="">
                            <select name="meterVerificationProvider" class="form-control w-full px-3 py-2 border border-gray-300 rounded-md" required>
                                <option value="">Select Api Provider</option>
                                <?php $meterVerificationProvider = $configs->get('meterVerificationProvider')->value ?? ''; ?>
                                <?php $__currentLoopData = $apiLinks->get('ElectricityVer', collect()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $apiLink): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($apiLink->value); ?>"
                                            <?php echo e($meterVerificationProvider == $apiLink->value ? 'selected' : ''); ?>>
                                        <?php echo e($apiLink->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group mb-4">
                        <label for="meterApi" class="control-label font-medium">Electricity Meter Api Key</label>
                        <div class="">
                            <input type="text" name="meterApi"
                                   value="<?php echo e($configs->get('meterApi')->value ?? ''); ?>"
                                   class="form-control w-full px-3 py-2 border border-gray-300 rounded-md">
                        </div>
                    </div>

                    <div class="form-group mb-4">
                        <label for="meterProvider" class="control-label font-medium">Electricity API Url</label>
                        <div class="">
                            <select name="meterProvider" class="form-control w-full px-3 py-2 border border-gray-300 rounded-md" required>
                                <option value="">Select Api Provider</option>
                                <?php $meterProvider = $configs->get('meterProvider')->value ?? ''; ?>
                                <?php $__currentLoopData = $apiLinks->get('Electricity', collect()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $apiLink): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($apiLink->value); ?>"
                                            <?php echo e($meterProvider == $apiLink->value ? 'selected' : ''); ?>>
                                        <?php echo e($apiLink->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <!-- Exam Configuration -->
                    <div class="form-group mb-4">
                        <label for="examApi" class="control-label font-medium">Exam Api Key</label>
                        <div class="">
                            <input type="text" name="examApi"
                                   value="<?php echo e($configs->get('examApi')->value ?? ''); ?>"
                                   class="form-control w-full px-3 py-2 border border-gray-300 rounded-md">
                        </div>
                    </div>

                    <div class="form-group mb-4">
                        <label for="examProvider" class="control-label font-medium">Exam Checker API Url</label>
                        <div class="">
                            <select name="examProvider" class="form-control w-full px-3 py-2 border border-gray-300 rounded-md" required>
                                <option value="">Select Api Provider</option>
                                <?php $examProvider = $configs->get('examProvider')->value ?? ''; ?>
                                <?php $__currentLoopData = $apiLinks->get('Exam', collect()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $apiLink): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($apiLink->value); ?>"
                                            <?php echo e($examProvider == $apiLink->value ? 'selected' : ''); ?>>
                                        <?php echo e($apiLink->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <!-- Recharge Card Configuration -->
                    <div class="form-group mb-4">
                        <label for="rechargePinApi" class="control-label font-medium">Recharge Card API Key</label>
                        <div class="">
                            <input type="text" name="rechargePinApi"
                                   value="<?php echo e($configs->get('rechargePinApi')->value ?? ''); ?>"
                                   class="form-control w-full px-3 py-2 border border-gray-300 rounded-md">
                        </div>
                    </div>

                    <div class="form-group mb-4">
                        <label for="rechargePinProvider" class="control-label font-medium">Recharge Card API Url</label>
                        <div class="">
                            <input type="text" name="rechargePinProvider"
                                   value="<?php echo e($configs->get('rechargePinProvider')->value ?? ''); ?>"
                                   class="form-control w-full px-3 py-2 border border-gray-300 rounded-md">
                        </div>
                    </div>

                    <!-- Data Pin Configuration -->
                    <div class="form-group mb-4">
                        <label for="dataPinApi" class="control-label font-medium">Data Pin Api Key</label>
                        <div class="">
                            <input type="text" name="dataPinApi"
                                   value="<?php echo e($configs->get('dataPinApi')->value ?? ''); ?>"
                                   class="form-control w-full px-3 py-2 border border-gray-300 rounded-md">
                        </div>
                    </div>

                    <div class="form-group mb-4">
                        <label for="dataPinProvider" class="control-label font-medium">Data Pin API Url</label>
                        <div class="">
                            <select name="dataPinProvider" class="form-control w-full px-3 py-2 border border-gray-300 rounded-md">
                                <option value="">Select Api Provider</option>
                                <?php $dataPinProvider = $configs->get('dataPinProvider')->value ?? ''; ?>
                                <?php $__currentLoopData = $apiLinks->get('Data Pin', collect()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $apiLink): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($apiLink->value); ?>"
                                            <?php echo e($dataPinProvider == $apiLink->value ? 'selected' : ''); ?>>
                                        <?php echo e($apiLink->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <!-- Alpha Topup Configuration -->
                    <div class="form-group mb-4">
                        <label for="alphaApi" class="control-label font-medium">Alpha Topup API Key</label>
                        <div class="">
                            <input type="text" name="alphaApi"
                                   value="<?php echo e($configs->get('alphaApi')->value ?? ''); ?>"
                                   class="form-control w-full px-3 py-2 border border-gray-300 rounded-md">
                        </div>
                    </div>

                    <div class="form-group mb-4">
                        <label for="alphaProvider" class="control-label font-medium">Alpha Topup API Url</label>
                        <div class="">
                            <input type="text" name="alphaProvider"
                                   value="<?php echo e($configs->get('alphaProvider')->value ?? ''); ?>"
                                   class="form-control w-full px-3 py-2 border border-gray-300 rounded-md">
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="">
                           <button type="submit" name="update-api-config" class="btn btn-info btn-submit">
                               <i class="fa fa-save" aria-hidden="true"></i> Update Details
                           </button>
                        </div>
                    </div>
                </form>
            </div>
            <!-- /.box-body -->
        </div>
        <!-- /.box -->
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
// Add any specific JavaScript for this page
document.addEventListener('DOMContentLoaded', function() {
    // Auto-save functionality could be added here
    console.log('API Configuration page loaded');
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\MrApollos\Documents\work\dbd_vtu_script_with_Nin_verify\laravel_version\resources\views/admin/api-configuration/index.blade.php ENDPATH**/ ?>