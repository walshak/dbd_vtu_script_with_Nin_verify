

<?php
    $title = 'Buy Airtime';
?>

<?php $__env->startSection('page-content'); ?>
<div class="container mx-auto px-6 py-8">
    <!-- Header Section -->
    <div class="mb-8">
        <div class="bg-gradient-to-r from-green-500 to-blue-600 rounded-2xl shadow-lg p-8 text-white relative overflow-hidden">
            <div class="relative z-10">
                <div class="flex items-center justify-center mb-4">
                    <div class="bg-white bg-opacity-20 p-4 rounded-full">
                        <i class="fas fa-mobile-alt text-4xl"></i>
                    </div>
                </div>
                <h1 class="text-3xl font-bold text-center mb-2">Buy Airtime</h1>
                <p class="text-green-100 text-lg text-center">Purchase airtime for all Nigerian networks with instant delivery</p>
            </div>
            <div class="absolute top-0 right-0 -mt-4 -mr-4 opacity-20">
                <i class="fas fa-signal text-9xl"></i>
            </div>
        </div>
    </div>

    <div class="max-w-4xl mx-auto">
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <!-- Purchase Form -->
            <div class="lg:col-span-2">
                <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-8">
                    <div class="flex items-center mb-6">
                        <div class="bg-green-100 p-3 rounded-lg mr-4">
                            <i class="fas fa-mobile-alt text-green-600 text-xl"></i>
                        </div>
                        <h2 class="text-xl font-semibold text-gray-900">Purchase Airtime</h2>
                    </div>

                    <form id="airtimeForm" class="space-y-6">
                        <?php echo csrf_field(); ?>
                        
                        <!-- Network Selection -->
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-4">
                                <i class="fas fa-signal mr-2"></i>Select Network Provider
                            </label>
                            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                                <?php $__currentLoopData = $networks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $network): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="network-option" data-network="<?php echo e(strtolower($network->network)); ?>">
                                    <input type="radio" id="network-<?php echo e(strtolower($network->network)); ?>" name="network" value="<?php echo e($network->network); ?>" class="sr-only" required>
                                    <label for="network-<?php echo e(strtolower($network->network)); ?>" class="network-label cursor-pointer block p-4 border-2 border-gray-200 rounded-xl text-center hover:border-green-300 hover:bg-green-50 transition-all duration-200">
                                        <div class="bg-green-100 w-12 h-12 rounded-lg flex items-center justify-center mx-auto mb-3">
                                            <?php if($network->logoPath): ?>
                                                <img src="<?php echo e($network->logoPath); ?>" alt="<?php echo e($network->network); ?>" class="w-8 h-8 object-contain" 
                                                     onerror="this.style.display='none'; this.nextElementSibling.style.display='block';">
                                                <span class="text-green-600 font-bold text-sm hidden"><?php echo e(strtoupper($network->network)); ?></span>
                                            <?php else: ?>
                                                <span class="text-green-600 font-bold text-sm"><?php echo e(strtoupper($network->network)); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <h3 class="font-medium text-gray-900 text-sm"><?php echo e(strtoupper($network->network)); ?></h3>
                                        <small class="text-green-600 text-xs">Best rates</small>
                                    </label>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="text-red-500 text-sm mt-2 hidden" id="network-error">Please select a network provider.</div>
                        </div>

                        <!-- Airtime Type -->
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-4">
                                <i class="fas fa-tags mr-2"></i>Airtime Type
                            </label>
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div class="airtime-type-option">
                                    <input type="radio" id="type-vtu" name="type" value="vtu" class="sr-only" required>
                                    <label for="type-vtu" class="type-label cursor-pointer block p-4 border-2 border-gray-200 rounded-xl hover:border-blue-300 hover:bg-blue-50 transition-all duration-200">
                                        <div class="flex items-center">
                                            <div class="bg-blue-100 p-3 rounded-lg mr-4">
                                                <i class="fas fa-mobile-alt text-blue-600"></i>
                                            </div>
                                            <div>
                                                <h3 class="font-medium text-gray-900">VTU Airtime</h3>
                                                <p class="text-sm text-gray-500">Direct top-up to phone number</p>
                                            </div>
                                        </div>
                                    </label>
                                </div>
                                <div class="airtime-type-option">
                                    <input type="radio" id="type-share-sell" name="type" value="share_sell" class="sr-only">
                                    <label for="type-share-sell" class="type-label cursor-pointer block p-4 border-2 border-gray-200 rounded-xl hover:border-purple-300 hover:bg-purple-50 transition-all duration-200">
                                        <div class="flex items-center">
                                            <div class="bg-purple-100 p-3 rounded-lg mr-4">
                                                <i class="fas fa-share-alt text-purple-600"></i>
                                            </div>
                                            <div>
                                                <h3 class="font-medium text-gray-900">Share & Sell</h3>
                                                <p class="text-sm text-gray-500">Transferable airtime</p>
                                            </div>
                                        </div>
                                    </label>
                                </div>
                            </div>
                        </div>

                        <!-- Phone Number & Amount -->
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label for="phone" class="block text-sm font-medium text-gray-700 mb-2">
                                    <i class="fas fa-phone mr-2"></i>Phone Number
                                </label>
                                <input type="tel" id="phone" name="phone" 
                                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                                       placeholder="08012345678" pattern="[0-9]{11}" maxlength="11" required>
                                <div class="text-red-500 text-sm mt-1 hidden" id="phone-error">Please enter a valid 11-digit phone number.</div>
                            </div>
                            <div>
                                <label for="amount" class="block text-sm font-medium text-gray-700 mb-2">
                                    <i class="fas fa-naira-sign mr-2"></i>Amount (₦)
                                </label>
                                <input type="number" id="amount" name="amount" 
                                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                                       placeholder="100" min="50" max="50000" step="50" required>
                                <div class="text-red-500 text-sm mt-1 hidden" id="amount-error">Please enter an amount between ₦50 and ₦50,000.</div>
                            </div>
                        </div>

                        <!-- Quick Amount Buttons -->
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-4">
                                <i class="fas fa-bolt mr-2"></i>Quick Amount Selection
                            </label>
                            <div class="grid grid-cols-3 md:grid-cols-6 gap-3">
                                <button type="button" class="amount-btn px-4 py-2 border-2 border-gray-200 rounded-lg text-center hover:border-green-500 hover:bg-green-50 transition-colors" data-amount="100">₦100</button>
                                <button type="button" class="amount-btn px-4 py-2 border-2 border-gray-200 rounded-lg text-center hover:border-green-500 hover:bg-green-50 transition-colors" data-amount="200">₦200</button>
                                <button type="button" class="amount-btn px-4 py-2 border-2 border-gray-200 rounded-lg text-center hover:border-green-500 hover:bg-green-50 transition-colors" data-amount="500">₦500</button>
                                <button type="button" class="amount-btn px-4 py-2 border-2 border-gray-200 rounded-lg text-center hover:border-green-500 hover:bg-green-50 transition-colors" data-amount="1000">₦1,000</button>
                                <button type="button" class="amount-btn px-4 py-2 border-2 border-gray-200 rounded-lg text-center hover:border-green-500 hover:bg-green-50 transition-colors" data-amount="2000">₦2,000</button>
                                <button type="button" class="amount-btn px-4 py-2 border-2 border-gray-200 rounded-lg text-center hover:border-green-500 hover:bg-green-50 transition-colors" data-amount="5000">₦5,000</button>
                            </div>
                        </div>

                        <!-- Pricing Information -->
                        <div id="pricing-info" class="hidden">
                            <div class="bg-gray-50 rounded-lg p-6 border border-gray-200">
                                <h3 class="text-lg font-medium text-gray-900 mb-4">
                                    <i class="fas fa-calculator mr-2"></i>Pricing Details
                                </h3>
                                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                                    <div class="text-center">
                                        <div class="text-2xl font-bold text-green-600" id="customer-price">₦0</div>
                                        <div class="text-sm text-gray-500">Customer Price</div>
                                    </div>
                                    <div class="text-center">
                                        <div class="text-2xl font-bold text-blue-600" id="our-price">₦0</div>
                                        <div class="text-sm text-gray-500">Our Price</div>
                                    </div>
                                    <div class="text-center">
                                        <div class="text-2xl font-bold text-purple-600" id="discount-amount">₦0</div>
                                        <div class="text-sm text-gray-500">You Save</div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Submit Button -->
                        <div class="flex justify-end">
                            <button type="submit" id="purchase-btn" 
                                    class="bg-gradient-to-r from-green-500 to-blue-600 text-white px-8 py-3 rounded-lg font-semibold hover:from-green-600 hover:to-blue-700 transition-all duration-300 transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed">
                                <i class="fas fa-shopping-cart mr-2"></i>Purchase Airtime
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Information Sidebar -->
            <div class="lg:col-span-1">
                <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6 mb-6">
                    <h3 class="text-lg font-semibold text-gray-900 mb-4">
                        <i class="fas fa-info-circle mr-2"></i>Purchase Information
                    </h3>
                    <div class="space-y-4">
                        <div class="flex items-start space-x-3">
                            <div class="bg-green-100 p-2 rounded-full">
                                <i class="fas fa-bolt text-green-600"></i>
                            </div>
                            <div>
                                <h4 class="font-medium text-gray-900">Instant Delivery</h4>
                                <p class="text-sm text-gray-500">Airtime delivered within seconds</p>
                            </div>
                        </div>
                        <div class="flex items-start space-x-3">
                            <div class="bg-blue-100 p-2 rounded-full">
                                <i class="fas fa-shield-alt text-blue-600"></i>
                            </div>
                            <div>
                                <h4 class="font-medium text-gray-900">Secure Payment</h4>
                                <p class="text-sm text-gray-500">Your transactions are protected</p>
                            </div>
                        </div>
                        <div class="flex items-start space-x-3">
                            <div class="bg-purple-100 p-2 rounded-full">
                                <i class="fas fa-percentage text-purple-600"></i>
                            </div>
                            <div>
                                <h4 class="font-medium text-gray-900">Best Rates</h4>
                                <p class="text-sm text-gray-500">Competitive pricing for all networks</p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Recent Transactions -->
                <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                    <h3 class="text-lg font-semibold text-gray-900 mb-4">
                        <i class="fas fa-history mr-2"></i>Recent Transactions
                    </h3>
                    <div class="space-y-3" id="recent-transactions">
                        <div class="text-center py-8 text-gray-500">
                            <i class="fas fa-clock text-2xl mb-2"></i>
                            <p class="text-sm">No recent transactions</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Loading Modal -->
<div id="loadingModal" class="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center hidden">
    <div class="bg-white rounded-xl p-8 max-w-sm mx-4">
        <div class="text-center">
            <div class="animate-spin h-12 w-12 border-4 border-blue-500 border-t-transparent rounded-full mx-auto mb-4"></div>
            <div class="text-gray-700" id="loadingText">Processing...</div>
        </div>
    </div>
</div>

<!-- Success Modal -->
<div id="successModal" class="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center hidden">
    <div class="bg-white rounded-xl max-w-lg mx-4 overflow-hidden">
        <div class="bg-gradient-to-r from-green-500 to-green-600 px-6 py-4 text-white">
            <h3 class="text-lg font-semibold">
                <i class="fas fa-check-circle mr-2"></i>Purchase Successful
            </h3>
        </div>
        <div class="p-6">
            <div id="successMessage"></div>
        </div>
        <div class="px-6 py-4 bg-gray-50 flex justify-end">
            <button type="button" onclick="hideModal('successModal')" 
                    class="bg-green-500 hover:bg-green-600 text-white px-6 py-2 rounded-lg transition-colors">
                Close
            </button>
        </div>
    </div>
</div>

<!-- Error Modal -->
<div id="errorModal" class="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center hidden">
    <div class="bg-white rounded-xl max-w-lg mx-4 overflow-hidden">
        <div class="bg-gradient-to-r from-red-500 to-red-600 px-6 py-4 text-white">
            <h3 class="text-lg font-semibold">
                <i class="fas fa-exclamation-circle mr-2"></i>Purchase Failed
            </h3>
        </div>
        <div class="p-6">
            <div id="errorMessage"></div>
        </div>
        <div class="px-6 py-4 bg-gray-50 flex justify-end">
            <button type="button" onclick="hideModal('errorModal')" 
                    class="bg-red-500 hover:bg-red-600 text-white px-6 py-2 rounded-lg transition-colors">
                Close
            </button>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$(document).ready(function() {
    let currentPricing = null;
    
    // Quick amount buttons
    $('.amount-btn').click(function(e) {
        e.preventDefault();
        const amount = $(this).data('amount');
        $('#amount').val(amount);
        
        // Remove active state from all buttons
        $('.amount-btn').removeClass('border-green-500 bg-green-50 text-green-700').addClass('border-gray-200');
        
        // Add active state to clicked button
        $(this).removeClass('border-gray-200').addClass('border-green-500 bg-green-50 text-green-700');
        
        updatePricing();
    });
    
    // Network selection handler
    $('input[name="network"]').change(function() {
        loadPricing();
        updateForm();
    });
    
    // Amount input handler
    $('#amount').on('input', function() {
        // Reset amount buttons when typing manually
        $('.amount-btn').removeClass('border-green-500 bg-green-50 text-green-700').addClass('border-gray-200');
        updatePricing();
        updateForm();
    });
    
    // Phone input handler
    $('#phone').on('input', function() {
        let phone = $(this).val().replace(/\D/g, '');
        if (phone.length > 11) {
            phone = phone.substr(0, 11);
        }
        $(this).val(phone);
        updateForm();
        
        // Auto-detect network
        if (phone.length >= 4) {
            detectNetwork(phone);
        }
    });
    
    // Auto-detect network based on phone number
    function detectNetwork(phone) {
        const prefix = phone.substring(0, 4);
        const networkMap = {
            '0803': 'mtn', '0806': 'mtn', '0810': 'mtn', '0813': 'mtn', '0814': 'mtn', 
            '0816': 'mtn', '0903': 'mtn', '0906': 'mtn', '0913': 'mtn', '0916': 'mtn',
            '0805': 'glo', '0807': 'glo', '0811': 'glo', '0815': 'glo', '0905': 'glo',
            '0802': 'airtel', '0808': 'airtel', '0812': 'airtel', '0901': 'airtel', '0902': 'airtel', '0904': 'airtel', '0907': 'airtel',
            '0809': '9mobile', '0817': '9mobile', '0818': '9mobile', '0909': '9mobile', '0908': '9mobile'
        };
        
        const detectedNetwork = networkMap[prefix];
        if (detectedNetwork && !$('input[name="network"]:checked').length) {
            $(`#network-${detectedNetwork}`).prop('checked', true).trigger('change');
        }
    }
    
    // Load pricing for selected network
    function loadPricing() {
        const network = $('input[name="network"]:checked').val();
        
        if (!network) return;
        
        $.ajax({
            url: '<?php echo e(route("airtime.pricing")); ?>',
            type: 'POST',
            data: {
                _token: '<?php echo e(csrf_token()); ?>',
                network: network
            },
            success: function(response) {
                if (response.status === 'success') {
                    currentPricing = response;
                    updatePricing();
                }
            },
            error: function() {
                console.error('Failed to load pricing');
            }
        });
    }
    
    // Update pricing display
    function updatePricing() {
        const amount = parseFloat($('#amount').val()) || 0;
        
        if (amount === 0 || !currentPricing) {
            $('#pricing-info').addClass('hidden');
            return;
        }
        
        // Calculate discount (using VTU discount as default)
        let discount = 0;
        if (currentPricing && currentPricing.data) {
            discount = currentPricing.data.vtu_discount || 0;
        }
        
        const discountAmount = (amount * discount) / 100;
        const finalAmount = amount - discountAmount;
        
        $('#customer-price').text('₦' + amount.toLocaleString());
        $('#our-price').text('₦' + finalAmount.toLocaleString('en-US', {minimumFractionDigits: 2}));
        $('#discount-amount').text('₦' + discountAmount.toLocaleString('en-US', {minimumFractionDigits: 2}));
        
        $('#pricing-info').removeClass('hidden');
    }
    
    // Update form state
    function updateForm() {
        const network = $('input[name="network"]:checked').val();
        const phone = $('#phone').val();
        const amount = parseFloat($('#amount').val()) || 0;
        
        const isValid = network && phone.length === 11 && amount >= 50 && amount <= 50000;
        
        const submitBtn = $('#purchase-btn');
        if (isValid) {
            submitBtn.removeClass('opacity-50 cursor-not-allowed').prop('disabled', false);
        } else {
            submitBtn.addClass('opacity-50 cursor-not-allowed').prop('disabled', true);
        }
    }
    
    // Form submission
    $('#airtimeForm').submit(function(e) {
        e.preventDefault();
        
        // Show validation errors if any
        let isValid = true;
        
        // Validate phone
        const phone = $('#phone').val();
        if (phone.length !== 11) {
            $('#phone-error').removeClass('hidden');
            isValid = false;
        } else {
            $('#phone-error').addClass('hidden');
        }
        
        // Validate amount
        const amount = parseFloat($('#amount').val()) || 0;
        if (amount < 50 || amount > 50000) {
            $('#amount-error').removeClass('hidden');
            isValid = false;
        } else {
            $('#amount-error').addClass('hidden');
        }
        
        if (!isValid) return;
        
        const formData = {
            _token: '<?php echo e(csrf_token()); ?>',
            network: $('input[name="network"]:checked').val(),
            phone: phone,
            amount: amount
        };
        
        showLoading('Processing airtime purchase...');
        
        $.ajax({
            url: '<?php echo e(route("airtime.purchase")); ?>',
            type: 'POST',
            data: formData,
            success: function(response) {
                hideLoading();
                if (response.status === 'success') {
                    showSuccess(response.message, response.data);
                    resetForm();
                } else {
                    showError(response.message || 'Purchase failed. Please try again.');
                }
            },
            error: function(xhr) {
                hideLoading();
                const response = xhr.responseJSON;
                showError(response?.message || 'Purchase failed. Please try again.');
            }
        });
    });
    
    // Helper functions
    function resetForm() {
        $('#airtimeForm')[0].reset();
        $('.amount-btn').removeClass('border-green-500 bg-green-50 text-green-700').addClass('border-gray-200');
        $('#pricing-info').addClass('hidden');
        $('#phone-error, #amount-error').addClass('hidden');
        $('#purchase-btn').addClass('opacity-50 cursor-not-allowed').prop('disabled', true);
        currentPricing = null;
    }
    
    // Initialize
    updateForm();
});

// Modal helper functions
function showLoading(text) {
    document.getElementById('loadingText').textContent = text;
    document.getElementById('loadingModal').classList.remove('hidden');
}

function hideLoading() {
    document.getElementById('loadingModal').classList.add('hidden');
}

function showSuccess(message, data) {
    let html = `<div class="bg-green-50 border border-green-200 rounded-lg p-4 mb-4">
                    <div class="text-green-800">${message}</div>
                </div>`;
    
    if (data) {
        html += `
            <div class="grid grid-cols-2 gap-4">
                <div><strong>Reference:</strong> ${data.reference || 'N/A'}</div>
                <div><strong>Amount:</strong> ₦${data.amount || 0}</div>
                <div><strong>Phone:</strong> ${data.phone || 'N/A'}</div>
                <div><strong>Network:</strong> ${data.network || 'N/A'}</div>
                <div><strong>Balance:</strong> ₦${data.balance || 0}</div>
                <div><strong>Profit:</strong> ₦${data.profit || 0}</div>
            </div>
        `;
    }
    
    document.getElementById('successMessage').innerHTML = html;
    document.getElementById('successModal').classList.remove('hidden');
}

function showError(message) {
    const html = `<div class="bg-red-50 border border-red-200 rounded-lg p-4">
                     <div class="text-red-800">${message}</div>
                  </div>`;
    document.getElementById('errorMessage').innerHTML = html;
    document.getElementById('errorModal').classList.remove('hidden');
}

function hideModal(modalId) {
    document.getElementById(modalId).classList.add('hidden');
}
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.user-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\MrApollos\Documents\work\dbd_vtu_script_with_Nin_verify\laravel_version\resources\views/airtime/index.blade.php ENDPATH**/ ?>