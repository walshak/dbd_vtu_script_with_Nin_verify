

<?php $__env->startSection('title', 'Cable TV Subscription'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <!-- Header -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h1 class="h3 mb-0 text-gray-800">
                        <i class="fas fa-tv text-purple"></i> Cable TV Subscription
                    </h1>
                    <p class="text-muted">Subscribe to DSTV, GOTV, StarTimes and other cable services</p>
                </div>
                <div>
                    <span class="badge badge-success fs-6">
                        <i class="fas fa-wallet"></i> ₦<?php echo e(number_format(auth()->user()->sWallet, 2)); ?>

                    </span>
                </div>
            </div>
        </div>
    </div>

    <?php if($maintenanceMode ?? false): ?>
    <div class="alert alert-warning alert-dismissible fade show" role="alert">
        <i class="fas fa-exclamation-triangle"></i>
        <strong>Maintenance Notice:</strong> <?php echo e($maintenanceMessage ?? 'Cable TV service is temporarily unavailable.'); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>

    <div class="row">
        <!-- Payment Form -->
        <div class="col-lg-8">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">
                        <i class="fas fa-credit-card"></i> Subscribe to Cable TV
                    </h6>
                </div>
                <div class="card-body">
                    <form id="cableTVForm" class="needs-validation" novalidate>
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="provider" class="form-label">
                                        <i class="fas fa-satellite-dish"></i> Select Cable Provider
                                    </label>
                                    <select class="form-select" id="provider" name="decoder" required>
                                        <option value="">Choose provider...</option>
                                        <?php $__currentLoopData = $providers ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($provider->network ?? $provider->name ?? $provider); ?>">
                                                <?php echo e(ucfirst($provider->name ?? $provider->network ?? $provider)); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <div class="invalid-feedback">
                                        Please select a cable provider.
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="iuc_number" class="form-label">
                                        <i class="fas fa-hashtag"></i> IUC/Smart Card Number
                                    </label>
                                    <input type="text" class="form-control" id="iuc_number" name="iuc_number" 
                                           placeholder="Enter IUC/Smart Card Number" required>
                                    <div class="invalid-feedback">
                                        Please enter a valid IUC/Smart Card number.
                                    </div>
                                    <div id="customer-info" class="mt-2" style="display: none;">
                                        <div class="alert alert-info">
                                            <strong>Customer:</strong> <span id="customer-name"></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="mb-3">
                                    <label for="plan" class="form-label">
                                        <i class="fas fa-th-list"></i> Select Subscription Plan
                                    </label>
                                    <select class="form-select" id="plan" name="plan_id" required disabled>
                                        <option value="">Select provider first...</option>
                                    </select>
                                    <div class="invalid-feedback">
                                        Please select a subscription plan.
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row" id="plan-details" style="display: none;">
                            <div class="col-md-12">
                                <div class="alert alert-success">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <strong>Plan:</strong> <span id="selected-plan-name"></span>
                                        </div>
                                        <div class="col-md-4">
                                            <strong>Amount:</strong> ₦<span id="selected-plan-amount"></span>
                                        </div>
                                        <div class="col-md-4">
                                            <strong>Duration:</strong> <span id="selected-plan-duration"></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="d-flex gap-3">
                                    <button type="button" id="validateBtn" class="btn btn-outline-primary" disabled>
                                        <i class="fas fa-check-circle"></i> Validate IUC
                                    </button>
                                    <button type="submit" id="subscribeBtn" class="btn btn-primary" disabled>
                                        <i class="fas fa-credit-card"></i> Subscribe Now
                                    </button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Sidebar -->
        <div class="col-lg-4">
            <!-- Quick Info -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-success">
                        <i class="fas fa-info-circle"></i> Service Information
                    </h6>
                </div>
                <div class="card-body">
                    <div class="row text-center">
                        <div class="col-6">
                            <div class="border-end">
                                <div class="h4 text-success mb-0">
                                    ₦<?php echo e(number_format($serviceCharges ?? 50)); ?>

                                </div>
                                <small class="text-muted">Service Charge</small>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="h4 text-primary mb-0">24/7</div>
                            <small class="text-muted">Support</small>
                        </div>
                    </div>
                    <hr>
                    <ul class="list-unstyled mb-0">
                        <li class="mb-2">
                            <i class="fas fa-check text-success"></i> 
                            Instant activation
                        </li>
                        <li class="mb-2">
                            <i class="fas fa-check text-success"></i> 
                            All subscription packages
                        </li>
                        <li class="mb-2">
                            <i class="fas fa-check text-success"></i> 
                            IUC validation
                        </li>
                        <li class="mb-0">
                            <i class="fas fa-check text-success"></i> 
                            Transaction history
                        </li>
                    </ul>
                </div>
            </div>

            <!-- Recent Transactions -->
            <?php if(!empty($recentTransactions) && count($recentTransactions) > 0): ?>
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-info">
                        <i class="fas fa-history"></i> Recent Subscriptions
                    </h6>
                </div>
                <div class="card-body">
                    <?php $__currentLoopData = $recentTransactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="d-flex align-items-center mb-3">
                        <div class="flex-shrink-0">
                            <i class="fas fa-tv text-purple"></i>
                        </div>
                        <div class="flex-grow-1 ms-3">
                            <div class="small font-weight-bold">
                                <?php echo e($transaction->servicename ?? 'Cable Subscription'); ?>

                            </div>
                            <div class="small text-muted">
                                ₦<?php echo e(number_format($transaction->amount ?? 0)); ?> • 
                                <?php echo e(\Carbon\Carbon::parse($transaction->date ?? $transaction->created_at)->format('M j, Y')); ?>

                            </div>
                        </div>
                        <div class="flex-shrink-0">
                            <span class="badge badge-<?php echo e(($transaction->status ?? 'success') == 'success' ? 'success' : 'warning'); ?>">
                                <?php echo e(ucfirst($transaction->status ?? 'completed')); ?>

                            </span>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <?php endif; ?>

            <!-- Supported Providers -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-warning">
                        <i class="fas fa-satellite-dish"></i> Supported Providers
                    </h6>
                </div>
                <div class="card-body">
                    <div class="row text-center">
                        <div class="col-4 mb-3">
                            <img src="/assets/images/dstv.png" alt="DSTV" class="img-fluid mb-2" style="height: 40px;" onerror="this.style.display='none'">
                            <div class="small">DSTV</div>
                        </div>
                        <div class="col-4 mb-3">
                            <img src="/assets/images/gotv.png" alt="GOTV" class="img-fluid mb-2" style="height: 40px;" onerror="this.style.display='none'">
                            <div class="small">GOTV</div>
                        </div>
                        <div class="col-4 mb-3">
                            <img src="/assets/images/startimes.png" alt="StarTimes" class="img-fluid mb-2" style="height: 40px;" onerror="this.style.display='none'">
                            <div class="small">StarTimes</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Loading Modal -->
<div class="modal fade" id="loadingModal" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-body text-center">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
                <div class="mt-3" id="loadingText">Processing...</div>
            </div>
        </div>
    </div>
</div>

<!-- Success Modal -->
<div class="modal fade" id="successModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-success text-white">
                <h5 class="modal-title">
                    <i class="fas fa-check-circle"></i> Subscription Successful
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div id="successMessage"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-success" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Error Modal -->
<div class="modal fade" id="errorModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title">
                    <i class="fas fa-exclamation-circle"></i> Subscription Failed
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div id="errorMessage"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$(document).ready(function() {
    let validateTimeout;
    
    // Provider change handler
    $('#provider').change(function() {
        const provider = $(this).val();
        const planSelect = $('#plan');
        const validateBtn = $('#validateBtn');
        const subscribeBtn = $('#subscribeBtn');
        
        // Reset form state
        planSelect.prop('disabled', true).html('<option value="">Loading plans...</option>');
        validateBtn.prop('disabled', true);
        subscribeBtn.prop('disabled', true);
        $('#customer-info').hide();
        $('#plan-details').hide();
        
        if (provider) {
            // Load plans for selected provider
            $.ajax({
                url: '<?php echo e(route("cable-tv.plans")); ?>',
                type: 'GET',
                data: { decoder: provider },
                success: function(response) {
                    planSelect.html('<option value="">Select plan...</option>');
                    if (response.success && response.data.length > 0) {
                        response.data.forEach(function(plan) {
                            planSelect.append(
                                `<option value="${plan.id}" data-amount="${plan.amount}" data-duration="${plan.duration || 'N/A'}">
                                    ${plan.name} - ₦${plan.amount}
                                </option>`
                            );
                        });
                        planSelect.prop('disabled', false);
                    } else {
                        planSelect.html('<option value="">No plans available</option>');
                    }
                },
                error: function() {
                    planSelect.html('<option value="">Error loading plans</option>');
                }
            });
        } else {
            planSelect.html('<option value="">Select provider first...</option>');
        }
    });
    
    // Plan selection handler
    $('#plan').change(function() {
        const selectedOption = $(this).find(':selected');
        const planId = $(this).val();
        
        if (planId) {
            $('#selected-plan-name').text(selectedOption.text().split(' - ')[0]);
            $('#selected-plan-amount').text(selectedOption.data('amount'));
            $('#selected-plan-duration').text(selectedOption.data('duration') || 'N/A');
            $('#plan-details').show();
            
            // Enable validate button if IUC is entered
            if ($('#iuc_number').val().trim()) {
                $('#validateBtn').prop('disabled', false);
            }
        } else {
            $('#plan-details').hide();
            $('#validateBtn').prop('disabled', true);
            $('#subscribeBtn').prop('disabled', true);
        }
    });
    
    // IUC number change handler
    $('#iuc_number').on('input', function() {
        const iucNumber = $(this).val().trim();
        const provider = $('#provider').val();
        
        $('#customer-info').hide();
        $('#subscribeBtn').prop('disabled', true);
        
        if (iucNumber && provider && $('#plan').val()) {
            $('#validateBtn').prop('disabled', false);
        } else {
            $('#validateBtn').prop('disabled', true);
        }
        
        // Clear previous timeout
        clearTimeout(validateTimeout);
        
        // Auto-validate after 2 seconds of no typing (optional)
        if (iucNumber.length >= 10 && provider) {
            validateTimeout = setTimeout(function() {
                $('#validateBtn').click();
            }, 2000);
        }
    });
    
    // Validate IUC button
    $('#validateBtn').click(function() {
        const provider = $('#provider').val();
        const iucNumber = $('#iuc_number').val().trim();
        
        if (!provider || !iucNumber) {
            showError('Please select provider and enter IUC number.');
            return;
        }
        
        const btn = $(this);
        btn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin"></i> Validating...');
        
        $.ajax({
            url: '<?php echo e(route("cable-tv.validate")); ?>',
            type: 'POST',
            data: {
                _token: '<?php echo e(csrf_token()); ?>',
                decoder: provider,
                iuc_number: iucNumber
            },
            success: function(response) {
                if (response.success && response.data.customerName) {
                    $('#customer-name').text(response.data.customerName);
                    $('#customer-info').show();
                    $('#subscribeBtn').prop('disabled', false);
                    btn.html('<i class="fas fa-check"></i> Validated').addClass('btn-success').removeClass('btn-outline-primary');
                } else {
                    showError(response.message || 'IUC validation failed.');
                    resetValidateButton();
                }
            },
            error: function(xhr) {
                const response = xhr.responseJSON;
                showError(response?.message || 'IUC validation failed.');
                resetValidateButton();
            }
        });
    });
    
    // Form submission
    $('#cableTVForm').submit(function(e) {
        e.preventDefault();
        
        if (!this.checkValidity()) {
            $(this).addClass('was-validated');
            return;
        }
        
        const formData = new FormData(this);
        showLoading('Processing subscription...');
        
        $.ajax({
            url: '<?php echo e(route("cable-tv.purchase")); ?>',
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                hideLoading();
                if (response.success || response.status === 'success') {
                    showSuccess(response.message || 'Subscription successful!');
                    resetForm();
                } else {
                    showError(response.message || 'Subscription failed.');
                }
            },
            error: function(xhr) {
                hideLoading();
                const response = xhr.responseJSON;
                showError(response?.message || 'Subscription failed. Please try again.');
            }
        });
    });
    
    // Helper functions
    function resetValidateButton() {
        $('#validateBtn').prop('disabled', false)
                         .html('<i class="fas fa-check-circle"></i> Validate IUC')
                         .removeClass('btn-success')
                         .addClass('btn-outline-primary');
    }
    
    function resetForm() {
        $('#cableTVForm')[0].reset();
        $('#cableTVForm').removeClass('was-validated');
        $('#plan').prop('disabled', true).html('<option value="">Select provider first...</option>');
        $('#customer-info').hide();
        $('#plan-details').hide();
        $('#validateBtn').prop('disabled', true);
        $('#subscribeBtn').prop('disabled', true);
        resetValidateButton();
    }
    
    function showLoading(text) {
        $('#loadingText').text(text);
        $('#loadingModal').modal('show');
    }
    
    function hideLoading() {
        $('#loadingModal').modal('hide');
    }
    
    function showSuccess(message) {
        $('#successMessage').html(message);
        $('#successModal').modal('show');
    }
    
    function showError(message) {
        $('#errorMessage').html(message);
        $('#errorModal').modal('show');
    }
});
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('styles'); ?>
<style>
.text-purple {
    color: #6f42c1 !important;
}

.badge-success {
    background-color: #28a745;
}

.card {
    border: none;
    border-radius: 0.5rem;
}

.card-header {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    border-radius: 0.5rem 0.5rem 0 0 !important;
}

.btn-primary {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    border: none;
}

.btn-primary:hover {
    background: linear-gradient(135deg, #5a6fd8 0%, #6a4190 100%);
    transform: translateY(-1px);
}

.form-control:focus,
.form-select:focus {
    border-color: #667eea;
    box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
}

.alert {
    border-radius: 0.5rem;
}

.modal-content {
    border-radius: 0.5rem;
}

.invalid-feedback {
    display: block;
}

@media (max-width: 768px) {
    .container-fluid {
        padding: 1rem;
    }
    
    .card-body {
        padding: 1rem;
    }
}
</style>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\MrApollos\Documents\work\dbd_vtu_script_with_Nin_verify\laravel_version\resources\views/cable-tv/index.blade.php ENDPATH**/ ?>