

<?php $__env->startSection('title', 'Buy Data Bundle'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <!-- Header -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h1 class="h3 mb-0 text-gray-800">
                        <i class="fas fa-wifi text-info"></i> Buy Data Bundle
                    </h1>
                    <p class="text-muted">Purchase data bundles for all Nigerian networks with instant activation</p>
                </div>
                <div>
                    <span class="badge badge-success fs-6">
                        <i class="fas fa-wallet"></i> ₦<?php echo e(number_format(auth()->user()->sWallet, 2)); ?>

                    </span>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <!-- Purchase Form -->
        <div class="col-lg-8">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">
                        <i class="fas fa-wifi"></i> Purchase Data Bundle
                    </h6>
                </div>
                <div class="card-body">
                    <form id="dataForm" class="needs-validation" novalidate>
                        <?php echo csrf_field(); ?>
                        
                        <!-- Network Selection -->
                        <div class="row mb-4">
                            <div class="col-12">
                                <label class="form-label">
                                    <i class="fas fa-signal"></i> Select Network Provider
                                </label>
                                <div class="row">
                                    <?php $__currentLoopData = $networks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $network): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-3 col-6 mb-3">
                                        <input type="radio" class="btn-check" name="network" id="network-<?php echo e(strtolower($network->network)); ?>" 
                                               value="<?php echo e($network->network); ?>" autocomplete="off" required>
                                        <label class="btn btn-outline-primary w-100 h-100 network-btn" for="network-<?php echo e(strtolower($network->network)); ?>">
                                            <div class="text-center py-2">
                                                <div class="network-logo mb-2">
                                                    <img src="<?php echo e($network->logoPath); ?>" alt="<?php echo e($network->network); ?>" 
                                                         class="img-fluid" style="height: 40px;" 
                                                         onerror="this.style.display='none'; this.nextElementSibling.style.display='block';">
                                                    <div style="display: none;">
                                                        <i class="fas fa-signal fa-2x text-<?php echo e($network->colorTheme); ?>"></i>
                                                    </div>
                                                </div>
                                                <div class="fw-bold"><?php echo e(strtoupper($network->network)); ?></div>
                                                <small class="text-muted">All plans</small>
                                            </div>
                                        </label>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="invalid-feedback">
                                    Please select a network provider.
                                </div>
                            </div>
                        </div>

                        <!-- Data Group Selection -->
                        <div class="row mb-4">
                            <div class="col-12">
                                <label class="form-label">
                                    <i class="fas fa-layer-group"></i> Data Type
                                </label>
                                <div class="row">
                                    <div class="col-md-4 mb-3">
                                        <input type="radio" class="btn-check" name="data_group" id="group-sme" 
                                               value="SME" autocomplete="off" checked>
                                        <label class="btn btn-outline-success w-100" for="group-sme">
                                            <div class="text-center py-2">
                                                <i class="fas fa-building fa-2x mb-2"></i>
                                                <div class="fw-bold">SME Data</div>
                                                <small class="text-muted">Corporate gifting</small>
                                            </div>
                                        </label>
                                    </div>
                                    <div class="col-md-4 mb-3">
                                        <input type="radio" class="btn-check" name="data_group" id="group-gifting" 
                                               value="Gifting" autocomplete="off">
                                        <label class="btn btn-outline-info w-100" for="group-gifting">
                                            <div class="text-center py-2">
                                                <i class="fas fa-gift fa-2x mb-2"></i>
                                                <div class="fw-bold">Gifting</div>
                                                <small class="text-muted">Direct gifting</small>
                                            </div>
                                        </label>
                                    </div>
                                    <div class="col-md-4 mb-3">
                                        <input type="radio" class="btn-check" name="data_group" id="group-corporate" 
                                               value="Corporate" autocomplete="off">
                                        <label class="btn btn-outline-warning w-100" for="group-corporate">
                                            <div class="text-center py-2">
                                                <i class="fas fa-briefcase fa-2x mb-2"></i>
                                                <div class="fw-bold">Corporate</div>
                                                <small class="text-muted">Bulk packages</small>
                                            </div>
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Phone Number -->
                        <div class="row mb-4">
                            <div class="col-md-8">
                                <label for="phone" class="form-label">
                                    <i class="fas fa-phone"></i> Beneficiary Phone Number
                                </label>
                                <input type="tel" class="form-control" id="phone" name="phone" 
                                       placeholder="08012345678" pattern="[0-9]{11}" maxlength="11" required>
                                <div class="invalid-feedback">
                                    Please enter a valid 11-digit phone number.
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">
                                    <i class="fas fa-exchange-alt"></i> Number Status
                                </label>
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="ported_number" name="ported_number">
                                    <label class="form-check-label" for="ported_number">
                                        Ported Number
                                    </label>
                                </div>
                                <small class="text-muted">Check if number was ported from another network</small>
                            </div>
                        </div>

                        <!-- Data Plans -->
                        <div class="row mb-4">
                            <div class="col-12">
                                <label class="form-label">
                                    <i class="fas fa-list"></i> Select Data Plan
                                </label>
                                <div id="data-plans-container">
                                    <div class="text-center py-4">
                                        <i class="fas fa-info-circle fa-2x text-muted mb-3"></i>
                                        <p class="text-muted">Please select a network and data type to view available plans</p>
                                    </div>
                                </div>
                                <input type="hidden" id="plan_id" name="plan_id" required>
                                <div class="invalid-feedback">
                                    Please select a data plan.
                                </div>
                            </div>
                        </div>

                        <!-- Purchase Summary -->
                        <div id="purchase-summary" class="row mb-4" style="display: none;">
                            <div class="col-12">
                                <div class="card bg-light">
                                    <div class="card-body">
                                        <h6 class="card-title">
                                            <i class="fas fa-receipt"></i> Purchase Summary
                                        </h6>
                                        <div class="row">
                                            <div class="col-md-3">
                                                <div class="text-center">
                                                    <div class="h6 mb-0" id="summary-plan">-</div>
                                                    <small class="text-muted">Data Plan</small>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="text-center">
                                                    <div class="h6 mb-0" id="summary-network">-</div>
                                                    <small class="text-muted">Network</small>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="text-center">
                                                    <div class="h6 mb-0" id="summary-phone">-</div>
                                                    <small class="text-muted">Phone Number</small>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="text-center">
                                                    <div class="h5 mb-0 text-primary" id="summary-amount">₦0</div>
                                                    <small class="text-muted">Amount</small>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Submit Button -->
                        <div class="row">
                            <div class="col-12">
                                <button type="submit" id="purchaseBtn" class="btn btn-primary btn-lg w-100" disabled>
                                    <i class="fas fa-shopping-cart"></i> Purchase Data Bundle
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Sidebar -->
        <div class="col-lg-4">
            <!-- Service Information -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-success">
                        <i class="fas fa-info-circle"></i> Service Features
                    </h6>
                </div>
                <div class="card-body">
                    <ul class="list-unstyled mb-0">
                        <li class="mb-2">
                            <i class="fas fa-check text-success"></i> 
                            Instant data activation
                        </li>
                        <li class="mb-2">
                            <i class="fas fa-check text-success"></i> 
                            All networks supported
                        </li>
                        <li class="mb-2">
                            <i class="fas fa-check text-success"></i> 
                            SME, Gifting & Corporate data
                        </li>
                        <li class="mb-2">
                            <i class="fas fa-check text-success"></i> 
                            Ported number support
                        </li>
                        <li class="mb-0">
                            <i class="fas fa-check text-success"></i> 
                            24/7 availability
                        </li>
                    </ul>
                </div>
            </div>

            <!-- Data Types Info -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-info">
                        <i class="fas fa-layer-group"></i> Data Types
                    </h6>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <strong class="text-success">SME Data</strong>
                        <p class="small mb-0">Corporate gifting plans with competitive rates</p>
                    </div>
                    <div class="mb-3">
                        <strong class="text-info">Gifting</strong>
                        <p class="small mb-0">Direct gifting data plans for personal use</p>
                    </div>
                    <div class="mb-0">
                        <strong class="text-warning">Corporate</strong>
                        <p class="small mb-0">Bulk data packages for business use</p>
                    </div>
                </div>
            </div>

            <!-- Network Status -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-warning">
                        <i class="fas fa-signal"></i> Network Status
                    </h6>
                </div>
                <div class="card-body">
                    <?php $__currentLoopData = $networks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $network): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <div class="d-flex align-items-center">
                            <img src="<?php echo e($network->logoPath); ?>" alt="<?php echo e($network->network); ?>" 
                                 class="me-2" style="height: 20px;" 
                                 onerror="this.style.display='none'">
                            <span><?php echo e(strtoupper($network->network)); ?></span>
                        </div>
                        <span class="badge badge-<?php echo e($network->isServiceEnabled('sme') ? 'success' : 'secondary'); ?>">
                            <?php echo e($network->isServiceEnabled('sme') ? 'Active' : 'Inactive'); ?>

                        </span>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <!-- Recent Transactions -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">
                        <i class="fas fa-history"></i> Recent Purchases
                    </h6>
                </div>
                <div class="card-body">
                    <div class="text-center py-3">
                        <i class="fas fa-wifi fa-3x text-muted mb-3"></i>
                        <p class="text-muted">Your recent data purchases will appear here</p>
                        <a href="#" class="btn btn-sm btn-outline-primary">
                            View All Transactions
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Loading Modal -->
<div class="modal fade" id="loadingModal" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-body text-center">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
                <div class="mt-3" id="loadingText">Loading...</div>
            </div>
        </div>
    </div>
</div>

<!-- Success Modal -->
<div class="modal fade" id="successModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-success text-white">
                <h5 class="modal-title">
                    <i class="fas fa-check-circle"></i> Purchase Successful
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div id="successMessage"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-success" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Error Modal -->
<div class="modal fade" id="errorModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title">
                    <i class="fas fa-exclamation-circle"></i> Purchase Failed
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div id="errorMessage"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$(document).ready(function() {
    let selectedPlan = null;
    let currentPlans = [];
    
    // Network selection handler
    $('input[name="network"]').change(function() {
        loadDataPlans();
        updateForm();
    });
    
    // Data group selection handler
    $('input[name="data_group"]').change(function() {
        loadDataPlans();
        updateForm();
    });
    
    // Phone input handler
    $('#phone').on('input', function() {
        let phone = $(this).val().replace(/\D/g, '');
        if (phone.length > 11) {
            phone = phone.substr(0, 11);
        }
        $(this).val(phone);
        updateForm();
        updateSummary();
        
        // Auto-detect network
        if (phone.length >= 4) {
            detectNetwork(phone);
        }
    });
    
    // Auto-detect network based on phone number
    function detectNetwork(phone) {
        const prefix = phone.substring(0, 4);
        const networkMap = {
            '0803': 'mtn', '0806': 'mtn', '0810': 'mtn', '0813': 'mtn', '0814': 'mtn', 
            '0816': 'mtn', '0903': 'mtn', '0906': 'mtn', '0913': 'mtn', '0916': 'mtn',
            '0805': 'glo', '0807': 'glo', '0811': 'glo', '0815': 'glo', '0905': 'glo',
            '0802': 'airtel', '0808': 'airtel', '0812': 'airtel', '0901': 'airtel', '0902': 'airtel', '0904': 'airtel', '0907': 'airtel',
            '0809': '9mobile', '0817': '9mobile', '0818': '9mobile', '0909': '9mobile', '0908': '9mobile'
        };
        
        const detectedNetwork = networkMap[prefix];
        if (detectedNetwork && !$('input[name="network"]:checked').length) {
            $(`#network-${detectedNetwork}`).prop('checked', true).trigger('change');
        }
    }
    
    // Load data plans based on network and group selection
    function loadDataPlans() {
        const network = $('input[name="network"]:checked').val();
        const dataGroup = $('input[name="data_group"]:checked').val();
        
        if (!network || !dataGroup) {
            showEmptyPlans();
            return;
        }
        
        showLoading('Loading data plans...');
        
        $.ajax({
            url: '<?php echo e(route("data.plans")); ?>',
            type: 'POST',
            data: {
                _token: '<?php echo e(csrf_token()); ?>',
                network: network,
                data_group: dataGroup
            },
            success: function(response) {
                hideLoading();
                if (response.status === 'success' && response.data.length > 0) {
                    currentPlans = response.data;
                    displayDataPlans(response.data);
                } else {
                    showNoPlans();
                }
            },
            error: function() {
                hideLoading();
                showNoPlans();
            }
        });
    }
    
    // Display data plans
    function displayDataPlans(plans) {
        let html = '<div class="row">';
        
        plans.forEach(function(plan, index) {
            html += `
                <div class="col-md-6 col-lg-4 mb-3">
                    <div class="card plan-card h-100" data-plan-id="${plan.id}" data-plan='${JSON.stringify(plan)}'>
                        <div class="card-body text-center">
                            <h5 class="card-title">${plan.name}</h5>
                            <div class="text-primary mb-2">
                                <h4>₦${parseFloat(plan.price).toLocaleString()}</h4>
                            </div>
                            <p class="card-text small text-muted">
                                <i class="fas fa-clock"></i> Valid for ${plan.validity}
                            </p>
                            <p class="card-text small">
                                <span class="badge badge-info">${plan.group}</span>
                            </p>
                        </div>
                    </div>
                </div>
            `;
        });
        
        html += '</div>';
        $('#data-plans-container').html(html);
        
        // Add click handlers for plan selection
        $('.plan-card').click(function() {
            $('.plan-card').removeClass('border-primary bg-light');
            $(this).addClass('border-primary bg-light');
            
            selectedPlan = JSON.parse($(this).attr('data-plan'));
            $('#plan_id').val(selectedPlan.id);
            
            updateForm();
            updateSummary();
        });
    }
    
    // Show empty plans state
    function showEmptyPlans() {
        $('#data-plans-container').html(`
            <div class="text-center py-4">
                <i class="fas fa-info-circle fa-2x text-muted mb-3"></i>
                <p class="text-muted">Please select a network and data type to view available plans</p>
            </div>
        `);
        selectedPlan = null;
        $('#plan_id').val('');
        updateForm();
    }
    
    // Show no plans available
    function showNoPlans() {
        $('#data-plans-container').html(`
            <div class="text-center py-4">
                <i class="fas fa-exclamation-circle fa-2x text-warning mb-3"></i>
                <p class="text-muted">No data plans available for the selected network and type</p>
            </div>
        `);
        selectedPlan = null;
        $('#plan_id').val('');
        updateForm();
    }
    
    // Update form state
    function updateForm() {
        const network = $('input[name="network"]:checked').val();
        const phone = $('#phone').val();
        const planId = $('#plan_id').val();
        
        const isValid = network && phone.length === 11 && planId;
        $('#purchaseBtn').prop('disabled', !isValid);
    }
    
    // Update purchase summary
    function updateSummary() {
        const network = $('input[name="network"]:checked').val();
        const phone = $('#phone').val();
        
        if (selectedPlan && network && phone.length === 11) {
            $('#summary-plan').text(selectedPlan.name);
            $('#summary-network').text(network.toUpperCase());
            $('#summary-phone').text(phone);
            $('#summary-amount').text('₦' + parseFloat(selectedPlan.price).toLocaleString());
            $('#purchase-summary').show();
        } else {
            $('#purchase-summary').hide();
        }
    }
    
    // Form submission
    $('#dataForm').submit(function(e) {
        e.preventDefault();
        
        if (!this.checkValidity()) {
            $(this).addClass('was-validated');
            return;
        }
        
        const formData = {
            _token: '<?php echo e(csrf_token()); ?>',
            network: $('input[name="network"]:checked').val(),
            phone: $('#phone').val(),
            plan_id: $('#plan_id').val(),
            data_group: $('input[name="data_group"]:checked').val(),
            ported_number: $('#ported_number').is(':checked')
        };
        
        showLoading('Processing data purchase...');
        
        $.ajax({
            url: '<?php echo e(route("data.purchase")); ?>',
            type: 'POST',
            data: formData,
            success: function(response) {
                hideLoading();
                if (response.status === 'success') {
                    showSuccess(response.message, response.data);
                    resetForm();
                } else {
                    showError(response.message || 'Purchase failed. Please try again.');
                }
            },
            error: function(xhr) {
                hideLoading();
                const response = xhr.responseJSON;
                showError(response?.message || 'Purchase failed. Please try again.');
            }
        });
    });
    
    // Helper functions
    function resetForm() {
        $('#dataForm')[0].reset();
        $('#dataForm').removeClass('was-validated');
        $('.plan-card').removeClass('border-primary bg-light');
        selectedPlan = null;
        $('#plan_id').val('');
        $('#purchase-summary').hide();
        $('#purchaseBtn').prop('disabled', true);
        
        // Reset to SME default
        $('#group-sme').prop('checked', true);
        showEmptyPlans();
    }
    
    function showLoading(text) {
        $('#loadingText').text(text);
        $('#loadingModal').modal('show');
    }
    
    function hideLoading() {
        $('#loadingModal').modal('hide');
    }
    
    function showSuccess(message, data) {
        let html = `<div class="alert alert-success">${message}</div>`;
        
        if (data) {
            html += `
                <div class="row">
                    <div class="col-md-6"><strong>Reference:</strong> ${data.reference || 'N/A'}</div>
                    <div class="col-md-6"><strong>Plan:</strong> ${data.plan || 'N/A'}</div>
                    <div class="col-md-6"><strong>Amount:</strong> ₦${data.amount || 0}</div>
                    <div class="col-md-6"><strong>Phone:</strong> ${data.phone || 'N/A'}</div>
                    <div class="col-md-6"><strong>Network:</strong> ${data.network || 'N/A'}</div>
                    <div class="col-md-6"><strong>Balance:</strong> ₦${data.balance || 0}</div>
                </div>
            `;
        }
        
        $('#successMessage').html(html);
        $('#successModal').modal('show');
    }
    
    function showError(message) {
        $('#errorMessage').html(`<div class="alert alert-danger">${message}</div>`);
        $('#errorModal').modal('show');
    }
    
    // Initialize
    updateForm();
});
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('styles'); ?>
<style>
.network-btn, .plan-card {
    min-height: 100px;
    transition: all 0.3s ease;
    cursor: pointer;
}

.network-btn:hover, .plan-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
}

.btn-check:checked + .network-btn {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    border-color: #667eea;
}

.plan-card.border-primary {
    border-width: 2px !important;
}

.card {
    border: none;
    border-radius: 0.5rem;
}

.card-header {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    border-radius: 0.5rem 0.5rem 0 0 !important;
}

.btn-primary {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    border: none;
}

.btn-primary:hover {
    background: linear-gradient(135deg, #5a6fd8 0%, #6a4190 100%);
    transform: translateY(-1px);
}

.form-control:focus,
.form-select:focus {
    border-color: #667eea;
    box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
}

.badge-success {
    background-color: #28a745;
}

@media (max-width: 768px) {
    .container-fluid {
        padding: 1rem;
    }
    
    .card-body {
        padding: 1rem;
    }
    
    .network-btn, .plan-card {
        min-height: 80px;
    }
}
</style>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\MrApollos\Documents\work\dbd_vtu_script_with_Nin_verify\laravel_version\resources\views/data/index.blade.php ENDPATH**/ ?>