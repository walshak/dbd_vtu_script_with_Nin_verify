<?php $__env->startSection('title', 'Data Plans Management'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-6 py-8">
    <!-- Header Section -->
    <div class="mb-8">
        <div class="bg-gradient-to-r from-blue-500 to-indigo-600 rounded-2xl shadow-lg p-6 text-white">
            <div class="flex justify-between items-center">
                <div>
                    <h1 class="text-3xl font-bold mb-2">Data Plans Management</h1>
                    <p class="text-blue-100 text-lg">Manage all data plans and pricing</p>
                </div>
                <div class="flex space-x-3">
                    <button onclick="openAddModal()" class="bg-green-600 hover:bg-green-700 text-white font-medium py-2 px-4 rounded-lg transition-colors duration-200">
                        <i class="fas fa-plus mr-2"></i>Add New
                    </button>
                    <button onclick="exportPlans()" class="bg-cyan-600 hover:bg-cyan-700 text-white font-medium py-2 px-4 rounded-lg transition-colors duration-200">
                        <i class="fas fa-download mr-2"></i>Export
                    </button>
                    <button onclick="bulkUpdatePrices()" class="bg-yellow-600 hover:bg-yellow-700 text-white font-medium py-2 px-4 rounded-lg transition-colors duration-200">
                        <i class="fas fa-edit mr-2"></i>Bulk Update
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Data Plans Table -->
    <div class="bg-white rounded-xl shadow-lg overflow-hidden">
        <div class="px-6 py-4 bg-gray-50 border-b border-gray-200">
            <div class="flex justify-between items-center">
                <h3 class="text-lg font-semibold text-gray-900">All Data Plans</h3>
                <div class="flex items-center space-x-2">
                    <input type="checkbox" id="selectAll" class="rounded border-gray-300 text-blue-600 focus:ring-blue-500">
                    <label for="selectAll" class="text-sm text-gray-600">Select All</label>
                </div>
            </div>
        </div>

        <div class="overflow-x-auto">
            <table id="dataPlansTable" class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            <input type="checkbox" id="selectAllTable" class="rounded border-gray-300 text-blue-600 focus:ring-blue-500">
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">#</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Plan Details</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Plan ID</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Buying Price</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">User Price</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Agent Price</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Vendor Price</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php $cnt = 1; ?>
                    <?php $__empty_1 = true; $__currentLoopData = $dataPlans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-gray-50 transition-colors duration-150">
                        <td class="px-6 py-4 whitespace-nowrap">
                            <input type="checkbox" class="plan-checkbox rounded border-gray-300 text-blue-600 focus:ring-blue-500" value="<?php echo e($plan->pId); ?>">
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo e($cnt++); ?></td>
                        <td class="px-6 py-4">
                            <div class="text-sm font-medium text-gray-900"><?php echo e($plan->name); ?></div>
                            <div class="text-sm text-gray-500">
                                <?php echo e(strtoupper($plan->datanetwork)); ?> <?php echo e($plan->type); ?>

                                (<?php echo e($plan->day); ?> Days)
                            </div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo e($plan->planid); ?></td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">₦<?php echo e(number_format($plan->price, 2)); ?></td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">₦<?php echo e(number_format($plan->userprice, 2)); ?></td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">₦<?php echo e(number_format($plan->agentprice, 2)); ?></td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">₦<?php echo e(number_format($plan->vendorprice, 2)); ?></td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <?php
                                $status = $plan->status ?? 'active';
                                $statusClass = $status === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800';
                            ?>
                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full <?php echo e($statusClass); ?>">
                                <?php echo e(ucfirst($status)); ?>

                            </span>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                            <div class="flex space-x-2">
                                <button onclick="editDataPlan(<?php echo e($plan->pId); ?>)"
                                        class="text-blue-600 hover:text-blue-900 transition-colors duration-150">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <button onclick="togglePlanStatus(<?php echo e($plan->pId); ?>)"
                                        class="text-<?php echo e($status === 'active' ? 'yellow' : 'green'); ?>-600 hover:text-<?php echo e($status === 'active' ? 'yellow' : 'green'); ?>-900 transition-colors duration-150">
                                    <i class="fas fa-<?php echo e($status === 'active' ? 'pause' : 'play'); ?>"></i>
                                </button>
                                <button onclick="deletePlan(<?php echo e($plan->pId); ?>)"
                                        class="text-red-600 hover:text-red-900 transition-colors duration-150">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="10" class="px-6 py-12 text-center">
                            <div class="flex flex-col items-center">
                                <i class="fas fa-database text-gray-400 text-4xl mb-4"></i>
                                <p class="text-gray-500 text-lg">No data plans found</p>
                                <p class="text-gray-400">Click "Add New" to create your first data plan</p>
                            </div>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Add Data Plan Modal -->
<div id="addDataPlans" class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full hidden z-50">
    <div class="relative top-20 mx-auto p-5 border w-11/12 md:w-3/4 lg:w-2/3 shadow-lg rounded-xl bg-white">
        <div class="mt-3">
            <div class="bg-gradient-to-r from-blue-500 to-indigo-600 -m-5 mb-4 px-6 py-4 rounded-t-xl">
                <div class="flex justify-between items-center">
                    <h3 class="text-xl font-bold text-white">Add New Data Plan</h3>
                    <button onclick="closeAddModal()" class="text-white hover:text-gray-200 text-2xl">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            </div>

            <form id="addDataPlanForm" method="post" class="space-y-4">
                <?php echo csrf_field(); ?>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div class="md:col-span-2">
                        <label for="network" class="block text-sm font-medium text-gray-700 mb-2">Network</label>
                        <select name="network" id="network" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required>
                            <option value="">Select Network</option>
                            <?php $__currentLoopData = $networks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $network): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($network->nId); ?>"><?php echo e(strtoupper($network->network)); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div>
                        <label for="dataname" class="block text-sm font-medium text-gray-700 mb-2">Plan Name</label>
                        <input type="text" placeholder="Plan Name" name="dataname" id="dataname"
                               class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required>
                    </div>

                    <div>
                        <label for="datatype" class="block text-sm font-medium text-gray-700 mb-2">Data Type</label>
                        <select name="datatype" id="datatype" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required>
                            <option value="Gifting">Gifting</option>
                            <option value="SME">SME</option>
                            <option value="Corporate">Corporate</option>
                        </select>
                    </div>

                    <div>
                        <label for="planid" class="block text-sm font-medium text-gray-700 mb-2">Plan ID</label>
                        <input type="text" placeholder="Plan ID" name="planid" id="planid"
                               class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required>
                    </div>

                    <div>
                        <label for="duration" class="block text-sm font-medium text-gray-700 mb-2">Duration (Days)</label>
                        <input type="number" placeholder="Days" name="duration" id="duration"
                               class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required>
                    </div>

                    <div class="md:col-span-2">
                        <label for="price" class="block text-sm font-medium text-gray-700 mb-2">Buying Price (₦)</label>
                        <input type="number" step="0.01" placeholder="Buying Price" name="price" id="price"
                               class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required>
                    </div>

                    <div>
                        <label for="userprice" class="block text-sm font-medium text-gray-700 mb-2">User Price (₦)</label>
                        <input type="number" step="0.01" placeholder="User Price" name="userprice" id="userprice"
                               class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required>
                    </div>

                    <div>
                        <label for="agentprice" class="block text-sm font-medium text-gray-700 mb-2">Agent Price (₦)</label>
                        <input type="number" step="0.01" placeholder="Agent Price" name="agentprice" id="agentprice"
                               class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required>
                    </div>

                    <div>
                        <label for="vendorprice" class="block text-sm font-medium text-gray-700 mb-2">Vendor Price (₦)</label>
                        <input type="number" step="0.01" placeholder="Vendor Price" name="vendorprice" id="vendorprice"
                               class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required>
                    </div>
                </div>

                <div class="flex justify-end space-x-3 pt-4">
                    <button type="button" onclick="closeAddModal()" class="bg-gray-500 hover:bg-gray-600 text-white font-medium py-2 px-4 rounded-lg transition-colors duration-200">
                        Cancel
                    </button>
                    <button type="button" onclick="submitDataPlan()" class="bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-lg transition-colors duration-200">
                        <i class="fas fa-plus mr-2"></i>Add Plan
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Data Plan Modal -->
<div id="editDataPlans" class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full hidden z-50">
    <div class="relative top-20 mx-auto p-5 border w-11/12 md:w-3/4 lg:w-2/3 shadow-lg rounded-xl bg-white">
        <div class="mt-3">
            <div class="bg-gradient-to-r from-green-500 to-blue-600 -m-5 mb-4 px-6 py-4 rounded-t-xl">
                <div class="flex justify-between items-center">
                    <h3 class="text-xl font-bold text-white">Edit Data Plan</h3>
                    <button onclick="closeEditModal()" class="text-white hover:text-gray-200 text-2xl">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            </div>

            <form id="editDataPlanForm" method="post" class="space-y-4">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <input type="hidden" id="editPlanId" name="plan_id">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div class="md:col-span-2">
                        <label for="editNetwork" class="block text-sm font-medium text-gray-700 mb-2">Network</label>
                        <select name="network" id="editNetwork" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required>
                            <option value="">Select Network</option>
                            <?php $__currentLoopData = $networks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $network): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($network->nId); ?>"><?php echo e(strtoupper($network->network)); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div>
                        <label for="editDataname" class="block text-sm font-medium text-gray-700 mb-2">Plan Name</label>
                        <input type="text" placeholder="Plan Name" name="dataname" id="editDataname"
                               class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required>
                    </div>

                    <div>
                        <label for="editDatatype" class="block text-sm font-medium text-gray-700 mb-2">Data Type</label>
                        <select name="datatype" id="editDatatype" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required>
                            <option value="Gifting">Gifting</option>
                            <option value="SME">SME</option>
                            <option value="Corporate">Corporate</option>
                        </select>
                    </div>

                    <div>
                        <label for="editPlanid" class="block text-sm font-medium text-gray-700 mb-2">Plan ID</label>
                        <input type="text" placeholder="Plan ID" name="planid" id="editPlanid"
                               class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required>
                    </div>

                    <div>
                        <label for="editDuration" class="block text-sm font-medium text-gray-700 mb-2">Duration (Days)</label>
                        <input type="number" placeholder="Days" name="duration" id="editDuration"
                               class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required>
                    </div>

                    <div class="md:col-span-2">
                        <label for="editPrice" class="block text-sm font-medium text-gray-700 mb-2">Buying Price (₦)</label>
                        <input type="number" step="0.01" placeholder="Buying Price" name="price" id="editPrice"
                               class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required>
                    </div>

                    <div>
                        <label for="editUserprice" class="block text-sm font-medium text-gray-700 mb-2">User Price (₦)</label>
                        <input type="number" step="0.01" placeholder="User Price" name="userprice" id="editUserprice"
                               class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required>
                    </div>

                    <div>
                        <label for="editAgentprice" class="block text-sm font-medium text-gray-700 mb-2">Agent Price (₦)</label>
                        <input type="number" step="0.01" placeholder="Agent Price" name="agentprice" id="editAgentprice"
                               class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required>
                    </div>

                    <div>
                        <label for="editVendorprice" class="block text-sm font-medium text-gray-700 mb-2">Vendor Price (₦)</label>
                        <input type="number" step="0.01" placeholder="Vendor Price" name="vendorprice" id="editVendorprice"
                               class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required>
                    </div>
                </div>

                <div class="flex justify-end space-x-3 pt-4">
                    <button type="button" onclick="closeEditModal()" class="bg-gray-500 hover:bg-gray-600 text-white font-medium py-2 px-4 rounded-lg transition-colors duration-200">
                        Cancel
                    </button>
                    <button type="button" onclick="updateDataPlan()" class="bg-green-600 hover:bg-green-700 text-white font-medium py-2 px-4 rounded-lg transition-colors duration-200">
                        <i class="fas fa-save mr-2"></i>Update Plan
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Bulk Update Prices Modal -->
<div id="bulkUpdateModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full hidden z-50">
    <div class="relative top-20 mx-auto p-5 border w-11/12 md:w-1/2 lg:w-1/3 shadow-lg rounded-xl bg-white">
        <div class="mt-3">
            <div class="bg-gradient-to-r from-yellow-500 to-orange-600 -m-5 mb-4 px-6 py-4 rounded-t-xl">
                <div class="flex justify-between items-center">
                    <h3 class="text-xl font-bold text-white">Bulk Update Prices</h3>
                    <button onclick="closeBulkModal()" class="text-white hover:text-gray-200 text-2xl">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            </div>

            <form id="bulkUpdateForm" class="space-y-4">
                <div>
                    <label for="priceType" class="block text-sm font-medium text-gray-700 mb-2">Price Type</label>
                    <select name="price_type" id="priceType" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required>
                        <option value="userprice">User Price</option>
                        <option value="agentprice">Agent Price</option>
                        <option value="vendorprice">Vendor Price</option>
                        <option value="price">Buying Price</option>
                    </select>
                </div>

                <div>
                    <label for="adjustmentType" class="block text-sm font-medium text-gray-700 mb-2">Adjustment Type</label>
                    <select name="adjustment_type" id="adjustmentType" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required>
                        <option value="percentage">Percentage</option>
                        <option value="fixed">Fixed Amount</option>
                    </select>
                </div>

                <div>
                    <label for="adjustmentValue" class="block text-sm font-medium text-gray-700 mb-2">Adjustment Value</label>
                    <input type="number" step="0.01" name="adjustment_value" id="adjustmentValue"
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required>
                    <p class="text-sm text-gray-500 mt-1">Use positive values to increase, negative to decrease</p>
                </div>

                <div class="flex justify-end space-x-3 pt-4">
                    <button type="button" onclick="closeBulkModal()" class="bg-gray-500 hover:bg-gray-600 text-white font-medium py-2 px-4 rounded-lg transition-colors duration-200">
                        Cancel
                    </button>
                    <button type="button" onclick="performBulkUpdate()" class="bg-yellow-600 hover:bg-yellow-700 text-white font-medium py-2 px-4 rounded-lg transition-colors duration-200">
                        <i class="fas fa-edit mr-2"></i>Update Prices
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Select all checkbox functionality
    const selectAll = document.getElementById('selectAll');
    const selectAllTable = document.getElementById('selectAllTable');
    const planCheckboxes = document.querySelectorAll('.plan-checkbox');

    // Sync both select all checkboxes
    if (selectAll) {
        selectAll.addEventListener('change', function() {
            selectAllTable.checked = this.checked;
            planCheckboxes.forEach(checkbox => {
                checkbox.checked = this.checked;
            });
        });
    }

    if (selectAllTable) {
        selectAllTable.addEventListener('change', function() {
            selectAll.checked = this.checked;
            planCheckboxes.forEach(checkbox => {
                checkbox.checked = this.checked;
            });
        });
    }

    // Update select all when individual checkboxes change
    planCheckboxes.forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            const checkedCount = document.querySelectorAll('.plan-checkbox:checked').length;
            const allChecked = checkedCount === planCheckboxes.length;
            const noneChecked = checkedCount === 0;

            selectAll.checked = allChecked;
            selectAllTable.checked = allChecked;
            selectAll.indeterminate = !allChecked && !noneChecked;
            selectAllTable.indeterminate = !allChecked && !noneChecked;
        });
    });
});

// Modal functions
function openAddModal() {
    document.getElementById('addDataPlans').classList.remove('hidden');
}

function closeAddModal() {
    document.getElementById('addDataPlans').classList.add('hidden');
    document.getElementById('addDataPlanForm').reset();
}

function closeEditModal() {
    document.getElementById('editDataPlans').classList.add('hidden');
    document.getElementById('editDataPlanForm').reset();
}

function closeBulkModal() {
    document.getElementById('bulkUpdateModal').classList.add('hidden');
    document.getElementById('bulkUpdateForm').reset();
}

// Close modals when clicking outside
document.getElementById('addDataPlans').addEventListener('click', function(e) {
    if (e.target === this) closeAddModal();
});

document.getElementById('editDataPlans').addEventListener('click', function(e) {
    if (e.target === this) closeEditModal();
});

document.getElementById('bulkUpdateModal').addEventListener('click', function(e) {
    if (e.target === this) closeBulkModal();
});

function submitDataPlan() {
    const form = document.getElementById('addDataPlanForm');
    const formData = new FormData(form);

    // Show loading state
    const submitBtn = event.target;
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Adding...';
    submitBtn.disabled = true;

    fetch('<?php echo e(route("admin.data-plans.store")); ?>', {
        method: 'POST',
        body: formData,
        headers: {
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            closeAddModal();
            location.reload();
        } else {
            alert('Error: ' + (data.message || 'Failed to add plan'));
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An error occurred while adding the plan');
    })
    .finally(() => {
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
    });
}

function editDataPlan(planId) {
    // Fetch plan data and populate edit form
    fetch(`<?php echo e(url('/admin/data-plans')); ?>/${planId}`)
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            const plan = data.plan;
            document.getElementById('editPlanId').value = plan.pId;
            document.getElementById('editNetwork').value = plan.dNetwork;
            document.getElementById('editDataname').value = plan.name;
            document.getElementById('editDatatype').value = plan.type;
            document.getElementById('editPlanid').value = plan.planid;
            document.getElementById('editDuration').value = plan.day;
            document.getElementById('editPrice').value = plan.price;
            document.getElementById('editUserprice').value = plan.userprice;
            document.getElementById('editAgentprice').value = plan.agentprice;
            document.getElementById('editVendorprice').value = plan.vendorprice;

            // Show modal
            document.getElementById('editDataPlans').classList.remove('hidden');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Failed to load plan data');
    });
}

function updateDataPlan() {
    const form = document.getElementById('editDataPlanForm');
    const formData = new FormData(form);
    const planId = document.getElementById('editPlanId').value;

    const submitBtn = event.target;
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Updating...';
    submitBtn.disabled = true;

    fetch(`<?php echo e(url('/admin/data-plans')); ?>/${planId}`, {
        method: 'POST',
        body: formData,
        headers: {
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            closeEditModal();
            location.reload();
        } else {
            alert('Error: ' + (data.message || 'Failed to update plan'));
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An error occurred while updating the plan');
    })
    .finally(() => {
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
    });
}

function deletePlan(planId) {
    if (confirm('Are you sure you want to delete this plan?')) {
        fetch(`<?php echo e(url('/admin/data-plans')); ?>/${planId}`, {
            method: 'DELETE',
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                'Content-Type': 'application/json'
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                alert('Error: ' + (data.message || 'Failed to delete plan'));
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while deleting the plan');
        });
    }
}

function togglePlanStatus(planId) {
    fetch(`<?php echo e(url('/admin/data-plans')); ?>/${planId}/toggle-status`, {
        method: 'POST',
        headers: {
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
            'Content-Type': 'application/json'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            location.reload();
        } else {
            alert('Error: ' + (data.message || 'Failed to toggle status'));
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An error occurred while toggling status');
    });
}

function bulkUpdatePrices() {
    const checkedPlans = Array.from(document.querySelectorAll('.plan-checkbox:checked')).map(cb => cb.value);

    if (checkedPlans.length === 0) {
        alert('Please select at least one plan to update');
        return;
    }

    // Store selected plan IDs
    window.selectedPlanIds = checkedPlans;

    // Show bulk update modal
    document.getElementById('bulkUpdateModal').classList.remove('hidden');
}

function performBulkUpdate() {
    const form = document.getElementById('bulkUpdateForm');
    const formData = new FormData(form);
    formData.append('plan_ids', JSON.stringify(window.selectedPlanIds));

    const submitBtn = event.target;
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Updating...';
    submitBtn.disabled = true;

    fetch('<?php echo e(route("admin.data-plans.bulk-update-prices")); ?>', {
        method: 'POST',
        body: formData,
        headers: {
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            closeBulkModal();
            location.reload();
        } else {
            alert('Error: ' + (data.message || 'Failed to update prices'));
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An error occurred while updating prices');
    })
    .finally(() => {
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
    });
}

function exportPlans() {
    window.location.href = '<?php echo e(route("admin.data-plans.export")); ?>?format=csv';
}
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\MrApollos\Documents\work\dbd_vtu_script_with_Nin_verify\laravel_version\resources\views/admin/data-plans/index.blade.php ENDPATH**/ ?>